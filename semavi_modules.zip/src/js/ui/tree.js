/**
 * SemAVi - Hierarchy Tree UI
 * @module ui/tree
 * @version 4.8
 * 
 * Manages the hierarchy tree display in the sidebar
 */

/**
 * Tree UI Manager Class
 */
class TreeUI {
    constructor(options = {}) {
        this.containerId = options.containerId || 'hierarchyContainer';
        this.onSelect = options.onSelect || (() => {});
        this.onExpand = options.onExpand || (() => {});
        this.onDelete = options.onDelete || (() => {});
        this.onAddChild = options.onAddChild || (() => {});
        this.onUpdateProperty = options.onUpdateProperty || (() => {});
        
        this.searchQuery = '';
        this.selectedItemId = null;
        this.expandedItems = new Set();
    }

    /**
     * Render the hierarchy tree
     * @param {Array} items - Hierarchy items
     * @param {Array} connections - Connections array
     */
    render(items, connections = []) {
        const container = document.getElementById(this.containerId);
        if (!container) return;

        if (!items || items.length === 0) {
            container.innerHTML = this.renderEmptyState();
            return;
        }

        // Get root items (no parent)
        const rootItems = items.filter(item => !item.parentId);
        
        // Build item map for quick lookup
        const itemMap = new Map(items.map(item => [item.id, item]));

        // Render tree
        let html = '<div class="tree-root">';
        rootItems.forEach((item, index) => {
            html += this.renderItem(item, itemMap, connections, [], index === rootItems.length - 1);
        });
        html += '</div>';

        container.innerHTML = html;

        // Apply search highlighting if active
        if (this.searchQuery) {
            this.highlightSearchMatches(container);
        }
    }

    /**
     * Render empty state
     * @returns {string} Empty state HTML
     */
    renderEmptyState() {
        return `
            <div class="empty-state">
                <h3>Keine Elemente vorhanden</h3>
                <p>Erstellen Sie ein neues Element oder importieren Sie ein Diagramm.</p>
                <button class="btn primary" onclick="window.treeUI?.onAddChild()">
                    ➕ Neues Element
                </button>
            </div>
        `;
    }

    /**
     * Render a single tree item (recursive)
     * @param {Object} item - Item to render
     * @param {Map} itemMap - Map of all items
     * @param {Array} connections - Connections array
     * @param {Array} lineTypes - Parent line types for drawing connections
     * @param {boolean} isLast - Whether this is the last child
     * @returns {string} Item HTML
     */
    renderItem(item, itemMap, connections, lineTypes, isLast) {
        const hasChildren = item.children && item.children.length > 0;
        const isExpanded = this.expandedItems.has(item.id);
        const isSelected = this.selectedItemId === item.id;
        
        // Get connections for this item
        const itemConnections = this.getItemConnections(item.id, connections);
        const connectionCount = itemConnections.outgoing.length + itemConnections.incoming.length;

        // Classes
        const classes = ['tree-item'];
        if (isExpanded) classes.push('expanded');
        if (isSelected) classes.push('selected');
        if (this.searchQuery && this.itemMatchesSearch(item)) classes.push('search-match');

        // Build HTML
        let html = `<div class="${classes.join(' ')}" data-item-id="${item.id}">`;
        
        // Tree item content
        html += `<div class="tree-item-content" onclick="window.treeUI?.selectItem('${item.id}')">`;
        
        // Tree lines (for nested items)
        if (lineTypes.length > 0) {
            html += '<div class="tree-indent">';
            lineTypes.forEach((type, i) => {
                html += `<div class="tree-line ${type}"></div>`;
            });
            html += '</div>';
        }

        // Toggle button
        html += `<button class="tree-toggle ${hasChildren ? '' : 'empty'}" onclick="event.stopPropagation(); window.treeUI?.toggleExpand('${item.id}')">`;
        if (hasChildren) {
            html += isExpanded ? '▼' : '▶';
        }
        html += '</button>';

        // Level indicator
        html += `<div class="level-indicator" data-level="${item.level % 10}"></div>`;

        // Item ID
        html += `<span class="item-id">${this.escapeHtml(item.id)}</span>`;

        // Item text
        const displayText = this.getDisplayText(item);
        html += `<span class="item-text" title="${this.escapeHtml(item.text || '')}">${this.escapeHtml(displayText)}</span>`;

        // Badges
        html += '<div class="item-badges">';
        if (item.isContainer) {
            html += '<span class="badge container">Subgraph</span>';
        }
        if (item.direction) {
            html += `<span class="badge direction">${item.direction}</span>`;
        }
        if (connectionCount > 0) {
            html += `<span class="badge connections">${connectionCount}</span>`;
        }
        if (item.styleClass || item.customStyle) {
            html += '<span class="badge styled">✨</span>';
        }
        html += '</div>';

        // Actions
        html += '<div class="item-actions">';
        html += `<button class="action-btn-small" onclick="event.stopPropagation(); window.treeUI?.onAddChild('${item.id}')" title="Kind hinzufügen">+</button>`;
        html += `<button class="action-btn-small delete" onclick="event.stopPropagation(); window.treeUI?.onDelete('${item.id}')" title="Löschen">×</button>`;
        html += '</div>';

        html += '</div>'; // .tree-item-content

        // Expanded details
        if (isSelected) {
            html += this.renderItemDetails(item, itemMap, itemConnections);
        }

        // Children (only if expanded)
        if (hasChildren && isExpanded) {
            html += '<div class="tree-children">';
            item.children.forEach((childId, index) => {
                const child = itemMap.get(childId);
                if (child) {
                    const newLineTypes = [...lineTypes, isLast ? '' : 'continue'];
                    html += this.renderItem(child, itemMap, connections, newLineTypes, index === item.children.length - 1);
                }
            });
            html += '</div>';
        }

        html += '</div>'; // .tree-item

        return html;
    }

    /**
     * Render item details panel
     * @param {Object} item - Item
     * @param {Map} itemMap - Item map
     * @param {Object} connections - Item connections
     * @returns {string} Details HTML
     */
    renderItemDetails(item, itemMap, connections) {
        let html = '<div class="item-details">';

        // Basic fields
        html += '<div class="detail-row">';
        html += `
            <div class="detail-field">
                <label class="detail-label">Text</label>
                <input type="text" class="detail-input" value="${this.escapeHtml(item.text || '')}" 
                       onchange="window.treeUI?.updateProperty('${item.id}', 'text', this.value)">
            </div>
        `;
        html += '</div>';

        // Type and Shape
        html += '<div class="detail-row">';
        html += `
            <div class="detail-field">
                <label class="detail-label">Typ</label>
                <select class="detail-select" onchange="window.treeUI?.updateProperty('${item.id}', 'isContainer', this.value === 'true')">
                    <option value="false" ${!item.isContainer ? 'selected' : ''}>Knoten</option>
                    <option value="true" ${item.isContainer ? 'selected' : ''}>Subgraph</option>
                </select>
            </div>
        `;

        if (!item.isContainer) {
            html += `
                <div class="detail-field">
                    <label class="detail-label">Form</label>
                    <select class="detail-select" onchange="window.treeUI?.updateProperty('${item.id}', 'shape', this.value)">
                        ${this.getShapeOptions(item.shape)}
                    </select>
                </div>
            `;
        } else {
            html += `
                <div class="detail-field">
                    <label class="detail-label">Richtung</label>
                    <select class="detail-select" onchange="window.treeUI?.updateProperty('${item.id}', 'direction', this.value || null)">
                        <option value="" ${!item.direction ? 'selected' : ''}>Vererbt</option>
                        <option value="TB" ${item.direction === 'TB' ? 'selected' : ''}>TB ↓</option>
                        <option value="BT" ${item.direction === 'BT' ? 'selected' : ''}>BT ↑</option>
                        <option value="LR" ${item.direction === 'LR' ? 'selected' : ''}>LR →</option>
                        <option value="RL" ${item.direction === 'RL' ? 'selected' : ''}>RL ←</option>
                    </select>
                </div>
            `;
        }
        html += '</div>';

        // Parent selection
        html += '<div class="detail-row">';
        html += `
            <div class="detail-field">
                <label class="detail-label">Übergeordnet</label>
                <select class="detail-select" onchange="window.treeUI?.changeParent('${item.id}', this.value)">
                    <option value="">Kein Parent (Root)</option>
                    ${this.getParentOptions(item, itemMap)}
                </select>
            </div>
        `;
        html += '</div>';

        // Action buttons
        html += '<div class="detail-actions">';
        html += `<button class="detail-btn add-child" onclick="window.treeUI?.onAddChild('${item.id}')">➕ Kind</button>`;
        html += `<button class="detail-btn connect" onclick="window.treeUI?.startConnection('${item.id}')">🔗 Verbinden</button>`;
        html += `<button class="detail-btn style" onclick="window.treeUI?.openStyleDialog('${item.id}')">🎨 Style</button>`;
        html += '</div>';

        // Connections section
        const totalConnections = connections.outgoing.length + connections.incoming.length;
        if (totalConnections > 0) {
            html += '<div class="connections-section">';
            html += `<div class="connections-title">Verbindungen (${totalConnections})</div>`;
            html += this.renderConnectionsList(item, connections, itemMap);
            html += '</div>';
        }

        html += '</div>';
        return html;
    }

    /**
     * Render connections list
     * @param {Object} item - Current item
     * @param {Object} connections - Item connections
     * @param {Map} itemMap - Item map
     * @returns {string} Connections HTML
     */
    renderConnectionsList(item, connections, itemMap) {
        let html = '';

        // Outgoing connections
        connections.outgoing.forEach(conn => {
            const target = itemMap.get(conn.to);
            html += `
                <div class="connection-item">
                    <span class="connection-arrow">→</span>
                    <span class="connection-target">${this.escapeHtml(target?.text || conn.to)}</span>
                    ${conn.label ? `<span class="connection-label">"${this.escapeHtml(conn.label)}"</span>` : ''}
                    <button class="connection-delete" onclick="window.treeUI?.deleteConnection('${conn.id}')" title="Löschen">×</button>
                </div>
            `;
        });

        // Incoming connections
        connections.incoming.forEach(conn => {
            const source = itemMap.get(conn.from);
            html += `
                <div class="connection-item">
                    <span class="connection-arrow">←</span>
                    <span class="connection-target">${this.escapeHtml(source?.text || conn.from)}</span>
                    ${conn.label ? `<span class="connection-label">"${this.escapeHtml(conn.label)}"</span>` : ''}
                    <button class="connection-delete" onclick="window.treeUI?.deleteConnection('${conn.id}')" title="Löschen">×</button>
                </div>
            `;
        });

        return html;
    }

    /**
     * Get connections for an item
     * @param {string} itemId - Item ID
     * @param {Array} connections - All connections
     * @returns {Object} { outgoing: [], incoming: [] }
     */
    getItemConnections(itemId, connections) {
        return {
            outgoing: connections.filter(c => c.from === itemId),
            incoming: connections.filter(c => c.to === itemId)
        };
    }

    /**
     * Get display text (first line only)
     * @param {Object} item - Item
     * @returns {string} Display text
     */
    getDisplayText(item) {
        const text = item.title || item.text || item.id;
        const firstLine = text.split('<br/>')[0];
        return firstLine.length > 50 ? firstLine.substring(0, 47) + '...' : firstLine;
    }

    /**
     * Get shape options HTML
     * @param {string} currentShape - Current shape
     * @returns {string} Options HTML
     */
    getShapeOptions(currentShape) {
        const shapes = [
            { value: 'rectangle', label: '▭ Rechteck' },
            { value: 'rounded', label: '▢ Abgerundet' },
            { value: 'stadium', label: '⊂ Stadium' },
            { value: 'circle', label: '○ Kreis' },
            { value: 'double-circle', label: '◎ Doppelkreis' },
            { value: 'rhombus', label: '◇ Raute' },
            { value: 'hexagon', label: '⬡ Hexagon' },
            { value: 'parallelogram', label: '▱ Parallelogramm' },
            { value: 'trapezoid', label: '⏢ Trapez' },
            { value: 'cylindrical', label: '⊙ Zylinder' },
            { value: 'subroutine', label: '▭▭ Subroutine' },
            { value: 'asymmetric', label: '⊳ Asymmetrisch' }
        ];

        return shapes.map(s => 
            `<option value="${s.value}" ${currentShape === s.value ? 'selected' : ''}>${s.label}</option>`
        ).join('');
    }

    /**
     * Get parent options HTML
     * @param {Object} item - Current item
     * @param {Map} itemMap - Item map
     * @returns {string} Options HTML
     */
    getParentOptions(item, itemMap) {
        const options = [];
        const descendants = this.getDescendants(item.id, itemMap);

        itemMap.forEach((potentialParent, id) => {
            // Can't be own parent or descendant
            if (id === item.id || descendants.has(id)) return;
            
            const indent = '  '.repeat(potentialParent.level);
            const selected = item.parentId === id ? 'selected' : '';
            options.push(`<option value="${id}" ${selected}>${indent}${this.escapeHtml(potentialParent.text || id)}</option>`);
        });

        return options.join('');
    }

    /**
     * Get all descendants of an item
     * @param {string} itemId - Item ID
     * @param {Map} itemMap - Item map
     * @returns {Set} Set of descendant IDs
     */
    getDescendants(itemId, itemMap) {
        const descendants = new Set();
        const item = itemMap.get(itemId);
        
        if (item && item.children) {
            item.children.forEach(childId => {
                descendants.add(childId);
                this.getDescendants(childId, itemMap).forEach(d => descendants.add(d));
            });
        }

        return descendants;
    }

    /**
     * Check if item matches search query
     * @param {Object} item - Item
     * @returns {boolean} True if matches
     */
    itemMatchesSearch(item) {
        if (!this.searchQuery) return false;
        const query = this.searchQuery.toLowerCase();
        return (item.text || '').toLowerCase().includes(query) ||
               item.id.toLowerCase().includes(query);
    }

    /**
     * Highlight search matches in container
     * @param {HTMLElement} container - Container element
     */
    highlightSearchMatches(container) {
        const matches = container.querySelectorAll('.search-match');
        matches.forEach(match => {
            // Expand parent chain
            let parent = match.parentElement;
            while (parent && !parent.classList.contains('tree-root')) {
                if (parent.classList.contains('tree-item')) {
                    parent.classList.add('expanded');
                }
                parent = parent.parentElement;
            }
        });
    }

    /**
     * Select an item
     * @param {string} itemId - Item ID
     */
    selectItem(itemId) {
        this.selectedItemId = itemId;
        this.expandedItems.add(itemId);
        this.onSelect(itemId);
    }

    /**
     * Toggle item expansion
     * @param {string} itemId - Item ID
     */
    toggleExpand(itemId) {
        if (this.expandedItems.has(itemId)) {
            this.expandedItems.delete(itemId);
        } else {
            this.expandedItems.add(itemId);
        }
        this.onExpand(itemId, this.expandedItems.has(itemId));
    }

    /**
     * Update item property
     * @param {string} itemId - Item ID
     * @param {string} property - Property name
     * @param {any} value - New value
     */
    updateProperty(itemId, property, value) {
        this.onUpdateProperty(itemId, property, value);
    }

    /**
     * Set search query
     * @param {string} query - Search query
     */
    setSearchQuery(query) {
        this.searchQuery = query;
    }

    /**
     * Set selected item
     * @param {string} itemId - Item ID
     */
    setSelectedItem(itemId) {
        this.selectedItemId = itemId;
    }

    /**
     * Set expanded items
     * @param {Set} items - Set of expanded item IDs
     */
    setExpandedItems(items) {
        this.expandedItems = items instanceof Set ? items : new Set(items);
    }

    /**
     * Escape HTML
     * @param {string} str - String to escape
     * @returns {string} Escaped string
     */
    escapeHtml(str) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return String(str || '').replace(/[&<>"']/g, m => map[m]);
    }
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { TreeUI };
}

// Export for browser
if (typeof window !== 'undefined') {
    window.TreeUI = TreeUI;
}

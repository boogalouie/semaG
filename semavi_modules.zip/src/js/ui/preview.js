/**
 * SemAVi - Diagram Preview UI
 * @module ui/preview
 * @version 4.8
 * 
 * Manages the Mermaid diagram preview with pan and zoom
 */

/**
 * Preview UI Manager Class
 */
class PreviewUI {
    constructor(options = {}) {
        this.containerId = options.containerId || 'previewContent';
        this.viewportId = options.viewportId || 'previewViewport';
        
        // Pan & Zoom state
        this.zoomLevel = 1;
        this.panX = 0;
        this.panY = 0;
        this.minZoom = 0.1;
        this.maxZoom = 5;
        this.zoomStep = 0.1;
        
        // Drag state
        this.isDragging = false;
        this.dragStartX = 0;
        this.dragStartY = 0;
        this.dragStartPanX = 0;
        this.dragStartPanY = 0;
        
        // Interaction mode
        this.interactionMode = 'pan'; // 'pan' or 'select'
        
        // Callbacks
        this.onNodeClick = options.onNodeClick || (() => {});
        this.onNodeDoubleClick = options.onNodeDoubleClick || (() => {});
        this.onZoomChange = options.onZoomChange || (() => {});
        
        // First render flag
        this.isFirstRender = true;
        
        // Mermaid instance
        this.mermaid = options.mermaid || window.mermaid;
        
        this.init();
    }

    /**
     * Initialize the preview
     */
    init() {
        this.container = document.getElementById(this.containerId);
        this.viewport = document.getElementById(this.viewportId);
        
        if (!this.container || !this.viewport) {
            console.warn('PreviewUI: Container or viewport not found');
            return;
        }

        this.setupEventListeners();
    }

    /**
     * Setup event listeners for pan and zoom
     */
    setupEventListeners() {
        // Mouse wheel for zoom
        this.viewport.addEventListener('wheel', this.handleWheel.bind(this), { passive: false });
        
        // Mouse events for pan
        this.container.addEventListener('mousedown', this.handleMouseDown.bind(this));
        document.addEventListener('mousemove', this.handleMouseMove.bind(this));
        document.addEventListener('mouseup', this.handleMouseUp.bind(this));
        
        // Touch events for mobile
        this.container.addEventListener('touchstart', this.handleTouchStart.bind(this), { passive: false });
        this.container.addEventListener('touchmove', this.handleTouchMove.bind(this), { passive: false });
        this.container.addEventListener('touchend', this.handleTouchEnd.bind(this));
    }

    /**
     * Handle mouse wheel for zoom
     * @param {WheelEvent} e - Wheel event
     */
    handleWheel(e) {
        e.preventDefault();
        
        const delta = e.deltaY > 0 ? -this.zoomStep : this.zoomStep;
        const newZoom = Math.max(this.minZoom, Math.min(this.maxZoom, this.zoomLevel + delta));
        
        if (newZoom !== this.zoomLevel) {
            // Zoom towards mouse position
            const rect = this.viewport.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;
            
            const zoomRatio = newZoom / this.zoomLevel;
            
            this.panX = mouseX - (mouseX - this.panX) * zoomRatio;
            this.panY = mouseY - (mouseY - this.panY) * zoomRatio;
            this.zoomLevel = newZoom;
            
            this.updateTransform();
            this.onZoomChange(this.zoomLevel);
        }
    }

    /**
     * Handle mouse down for drag
     * @param {MouseEvent} e - Mouse event
     */
    handleMouseDown(e) {
        if (e.button !== 0) return; // Only left click
        
        if (this.interactionMode === 'pan' || e.target === this.container || e.target.closest('svg')) {
            this.isDragging = true;
            this.dragStartX = e.clientX;
            this.dragStartY = e.clientY;
            this.dragStartPanX = this.panX;
            this.dragStartPanY = this.panY;
            this.container.style.cursor = 'grabbing';
        }
    }

    /**
     * Handle mouse move for drag
     * @param {MouseEvent} e - Mouse event
     */
    handleMouseMove(e) {
        if (!this.isDragging) return;
        
        const dx = e.clientX - this.dragStartX;
        const dy = e.clientY - this.dragStartY;
        
        this.panX = this.dragStartPanX + dx;
        this.panY = this.dragStartPanY + dy;
        
        this.updateTransform();
    }

    /**
     * Handle mouse up
     * @param {MouseEvent} e - Mouse event
     */
    handleMouseUp(e) {
        this.isDragging = false;
        this.container.style.cursor = this.interactionMode === 'pan' ? 'move' : 'default';
    }

    /**
     * Handle touch start
     * @param {TouchEvent} e - Touch event
     */
    handleTouchStart(e) {
        if (e.touches.length === 1) {
            this.isDragging = true;
            this.dragStartX = e.touches[0].clientX;
            this.dragStartY = e.touches[0].clientY;
            this.dragStartPanX = this.panX;
            this.dragStartPanY = this.panY;
        }
    }

    /**
     * Handle touch move
     * @param {TouchEvent} e - Touch event
     */
    handleTouchMove(e) {
        if (!this.isDragging || e.touches.length !== 1) return;
        e.preventDefault();
        
        const dx = e.touches[0].clientX - this.dragStartX;
        const dy = e.touches[0].clientY - this.dragStartY;
        
        this.panX = this.dragStartPanX + dx;
        this.panY = this.dragStartPanY + dy;
        
        this.updateTransform();
    }

    /**
     * Handle touch end
     * @param {TouchEvent} e - Touch event
     */
    handleTouchEnd(e) {
        this.isDragging = false;
    }

    /**
     * Update CSS transform
     */
    updateTransform() {
        if (!this.container) return;
        
        this.container.style.transform = `translate(${this.panX}px, ${this.panY}px) scale(${this.zoomLevel})`;
        this.updateZoomDisplay();
    }

    /**
     * Update zoom display
     */
    updateZoomDisplay() {
        const display = document.getElementById('zoomLevel');
        if (display) {
            display.textContent = `${Math.round(this.zoomLevel * 100)}%`;
        }
    }

    /**
     * Render Mermaid diagram
     * @param {string} code - Mermaid code
     * @returns {Promise<void>}
     */
    async render(code) {
        if (!this.container || !this.mermaid) return;
        
        if (!code || !code.trim()) {
            this.container.innerHTML = '<div style="color: var(--text-muted); padding: 20px;">Keine Vorschau verfügbar</div>';
            return;
        }

        // Save current state
        const savedZoom = this.zoomLevel;
        const savedPanX = this.panX;
        const savedPanY = this.panY;
        const shouldRestore = !this.isFirstRender;

        try {
            this.container.innerHTML = '';
            const id = 'mermaid-preview-' + Date.now();
            
            const result = await this.mermaid.render(id, code);
            this.container.innerHTML = result.svg;
            
            // Setup node handlers
            this.setupNodeHandlers();
            
            // Initialize or restore pan/zoom
            setTimeout(() => {
                if (shouldRestore) {
                    this.restorePanZoom(savedZoom, savedPanX, savedPanY);
                } else {
                    this.initializePanZoom();
                    this.isFirstRender = false;
                }
            }, 100);
            
        } catch (err) {
            this.container.innerHTML = `<div style="color: var(--accent-red); padding: 20px;">Fehler: ${err.message}</div>`;
        }
    }

    /**
     * Setup click handlers for nodes
     */
    setupNodeHandlers() {
        const svg = this.container.querySelector('svg');
        if (!svg) return;
        
        const nodes = svg.querySelectorAll('.node, .cluster');
        
        nodes.forEach(node => {
            const nodeId = this.extractNodeId(node);
            node.dataset.nodeId = nodeId;
            node.style.cursor = 'pointer';
            
            // Single click
            node.addEventListener('click', (e) => {
                if (!this.isDragging) {
                    e.stopPropagation();
                    this.onNodeClick(nodeId, node, e);
                }
            });
            
            // Double click
            node.addEventListener('dblclick', (e) => {
                e.stopPropagation();
                this.onNodeDoubleClick(nodeId, node, e);
            });
            
            // Hover effect
            node.addEventListener('mouseenter', () => {
                this.highlightNode(node);
            });
            
            node.addEventListener('mouseleave', () => {
                this.unhighlightNode(node);
            });
        });
    }

    /**
     * Extract node ID from SVG element
     * @param {Element} node - SVG node element
     * @returns {string} Node ID
     */
    extractNodeId(node) {
        let nodeId = node.id || '';
        
        // Mermaid uses formats like "flowchart-NodeId-123"
        const match = nodeId.match(/flowchart-([^-]+)-\d+/) || nodeId.match(/^([A-Za-z_][A-Za-z0-9_.-]*)$/);
        if (match) {
            return match[1];
        }
        
        // Try to get from label
        const label = node.querySelector('.nodeLabel, .cluster-label');
        if (label) {
            return label.textContent.trim();
        }
        
        return nodeId;
    }

    /**
     * Highlight a node
     * @param {Element} node - SVG node element
     */
    highlightNode(node) {
        const shapes = node.querySelectorAll('rect, circle, polygon, path, ellipse');
        shapes.forEach(shape => {
            shape.style.filter = 'brightness(1.1)';
            shape.style.strokeWidth = '2px';
        });
    }

    /**
     * Unhighlight a node
     * @param {Element} node - SVG node element
     */
    unhighlightNode(node) {
        const shapes = node.querySelectorAll('rect, circle, polygon, path, ellipse');
        shapes.forEach(shape => {
            shape.style.filter = '';
            shape.style.strokeWidth = '';
        });
    }

    /**
     * Highlight selected node
     * @param {string} nodeId - Node ID to highlight
     */
    highlightSelectedNode(nodeId) {
        const svg = this.container.querySelector('svg');
        if (!svg) return;
        
        // Remove previous highlight
        svg.querySelectorAll('.node, .cluster').forEach(node => {
            node.style.outline = '';
        });
        
        // Add highlight to selected node
        const selectedNode = svg.querySelector(`[data-node-id="${nodeId}"]`);
        if (selectedNode) {
            selectedNode.style.outline = '3px solid var(--accent-blue)';
            selectedNode.style.outlineOffset = '2px';
        }
    }

    /**
     * Initialize pan/zoom for first render
     */
    initializePanZoom() {
        const svg = this.container.querySelector('svg');
        if (!svg || !this.viewport) return;
        
        const svgRect = svg.getBoundingClientRect();
        const viewportRect = this.viewport.getBoundingClientRect();
        
        // Calculate zoom to fit
        const scaleX = viewportRect.width / (svgRect.width + 40);
        const scaleY = viewportRect.height / (svgRect.height + 40);
        this.zoomLevel = Math.min(scaleX, scaleY, 1);
        this.zoomLevel = Math.max(this.minZoom, Math.min(this.maxZoom, this.zoomLevel));
        
        // Center the diagram
        const scaledWidth = svgRect.width * this.zoomLevel;
        const scaledHeight = svgRect.height * this.zoomLevel;
        
        this.panX = (viewportRect.width - scaledWidth) / 2 - svgRect.width / 2 * this.zoomLevel;
        this.panY = (viewportRect.height - scaledHeight) / 2 - svgRect.height / 2 * this.zoomLevel;
        
        this.updateTransform();
    }

    /**
     * Restore pan/zoom state
     * @param {number} zoom - Zoom level
     * @param {number} panX - Pan X
     * @param {number} panY - Pan Y
     */
    restorePanZoom(zoom, panX, panY) {
        this.zoomLevel = zoom;
        this.panX = panX;
        this.panY = panY;
        this.updateTransform();
    }

    /**
     * Zoom in
     */
    zoomIn() {
        this.zoomLevel = Math.min(this.maxZoom, this.zoomLevel + this.zoomStep);
        this.updateTransform();
        this.onZoomChange(this.zoomLevel);
    }

    /**
     * Zoom out
     */
    zoomOut() {
        this.zoomLevel = Math.max(this.minZoom, this.zoomLevel - this.zoomStep);
        this.updateTransform();
        this.onZoomChange(this.zoomLevel);
    }

    /**
     * Reset zoom
     */
    resetZoom() {
        this.isFirstRender = true;
        this.initializePanZoom();
        this.onZoomChange(this.zoomLevel);
    }

    /**
     * Set interaction mode
     * @param {string} mode - 'pan' or 'select'
     */
    setInteractionMode(mode) {
        this.interactionMode = mode;
        this.container.style.cursor = mode === 'pan' ? 'move' : 'default';
        
        if (mode === 'select') {
            this.container.classList.add('select-mode');
        } else {
            this.container.classList.remove('select-mode');
        }
    }

    /**
     * Get current state
     * @returns {Object} Current state
     */
    getState() {
        return {
            zoomLevel: this.zoomLevel,
            panX: this.panX,
            panY: this.panY,
            interactionMode: this.interactionMode
        };
    }

    /**
     * Set state
     * @param {Object} state - State to restore
     */
    setState(state) {
        if (state.zoomLevel !== undefined) this.zoomLevel = state.zoomLevel;
        if (state.panX !== undefined) this.panX = state.panX;
        if (state.panY !== undefined) this.panY = state.panY;
        if (state.interactionMode !== undefined) this.setInteractionMode(state.interactionMode);
        this.updateTransform();
    }

    /**
     * Focus on a specific node
     * @param {string} nodeId - Node ID to focus
     */
    focusOnNode(nodeId) {
        const svg = this.container.querySelector('svg');
        if (!svg) return;
        
        const node = svg.querySelector(`[data-node-id="${nodeId}"]`);
        if (!node) return;
        
        const nodeRect = node.getBoundingClientRect();
        const viewportRect = this.viewport.getBoundingClientRect();
        
        // Calculate center position
        const nodeCenterX = nodeRect.left + nodeRect.width / 2 - viewportRect.left;
        const nodeCenterY = nodeRect.top + nodeRect.height / 2 - viewportRect.top;
        
        const viewportCenterX = viewportRect.width / 2;
        const viewportCenterY = viewportRect.height / 2;
        
        // Adjust pan to center node
        this.panX += (viewportCenterX - nodeCenterX);
        this.panY += (viewportCenterY - nodeCenterY);
        
        this.updateTransform();
        this.highlightSelectedNode(nodeId);
    }

    /**
     * Export current view as SVG
     * @returns {string} SVG string
     */
    exportSVG() {
        const svg = this.container.querySelector('svg');
        if (!svg) return '';
        return new XMLSerializer().serializeToString(svg);
    }

    /**
     * Export current view as PNG
     * @returns {Promise<Blob>} PNG blob
     */
    async exportPNG() {
        const svg = this.container.querySelector('svg');
        if (!svg) return null;
        
        const svgData = new XMLSerializer().serializeToString(svg);
        const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
        const url = URL.createObjectURL(svgBlob);
        
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                canvas.width = svg.getBoundingClientRect().width * 2;
                canvas.height = svg.getBoundingClientRect().height * 2;
                
                const ctx = canvas.getContext('2d');
                ctx.fillStyle = 'white';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                
                canvas.toBlob(blob => {
                    URL.revokeObjectURL(url);
                    resolve(blob);
                }, 'image/png');
            };
            img.onerror = reject;
            img.src = url;
        });
    }
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { PreviewUI };
}

// Export for browser
if (typeof window !== 'undefined') {
    window.PreviewUI = PreviewUI;
}

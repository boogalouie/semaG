/**
 * SemAVi - Dialog Manager
 * @module ui/dialogs
 * @version 4.8
 * 
 * Manages modal dialogs for import, export, connections, and styles
 */

/**
 * Dialog Manager Class
 */
class DialogManager {
    constructor(options = {}) {
        this.onImport = options.onImport || (() => {});
        this.onExport = options.onExport || (() => {});
        this.onConnectionCreate = options.onConnectionCreate || (() => {});
        this.onStyleApply = options.onStyleApply || (() => {});
        
        this.activeDialog = null;
    }

    /**
     * Open import dialog
     */
    openImportDialog() {
        const dialog = document.getElementById('importDialog');
        if (dialog) {
            dialog.classList.add('active');
            this.activeDialog = 'import';
            
            const textarea = document.getElementById('importTextarea');
            if (textarea) textarea.value = '';
        }
    }

    /**
     * Close import dialog
     */
    closeImportDialog() {
        const dialog = document.getElementById('importDialog');
        if (dialog) {
            dialog.classList.remove('active');
            this.activeDialog = null;
        }
    }

    /**
     * Execute import from dialog
     */
    executeImport() {
        const textarea = document.getElementById('importTextarea');
        const formatSelect = document.getElementById('importFormat');
        
        if (!textarea || !textarea.value.trim()) {
            this.showNotification('Bitte fügen Sie Inhalt zum Importieren ein.', 'error');
            return;
        }
        
        const format = formatSelect?.value || 'auto';
        const content = textarea.value.trim();
        
        try {
            this.onImport(content, format);
            this.closeImportDialog();
            this.showNotification('Import erfolgreich!', 'success');
        } catch (err) {
            this.showNotification('Import-Fehler: ' + err.message, 'error');
        }
    }

    /**
     * Open export dialog
     * @param {Object} data - Data to export
     */
    openExportDialog(data) {
        const dialog = document.getElementById('exportDialog');
        if (dialog) {
            dialog.classList.add('active');
            this.activeDialog = 'export';
            this.updateExportPreview(data);
        }
    }

    /**
     * Close export dialog
     */
    closeExportDialog() {
        const dialog = document.getElementById('exportDialog');
        if (dialog) {
            dialog.classList.remove('active');
            this.activeDialog = null;
        }
    }

    /**
     * Update export preview
     * @param {Object} data - Data to export
     */
    updateExportPreview(data) {
        const formatSelect = document.getElementById('exportFormat');
        const preview = document.getElementById('exportPreview');
        
        if (!formatSelect || !preview) return;
        
        const format = formatSelect.value;
        let content = '';
        
        switch (format) {
            case 'mermaid':
                content = this.generateMermaidCode(data);
                break;
            case 'jsonld':
                content = this.generateJsonLD(data);
                break;
            case 'json':
                content = JSON.stringify(data, null, 2);
                break;
            default:
                content = 'Format nicht unterstützt';
        }
        
        preview.value = content;
    }

    /**
     * Execute export
     * @param {Object} data - Data to export
     */
    executeExport(data) {
        const formatSelect = document.getElementById('exportFormat');
        const format = formatSelect?.value || 'mermaid';
        
        this.onExport(data, format);
        this.closeExportDialog();
    }

    /**
     * Open connection dialog
     * @param {string} sourceId - Source node ID
     * @param {string} targetId - Target node ID
     */
    openConnectionDialog(sourceId, targetId) {
        const dialog = document.getElementById('connectionDialog');
        if (!dialog) return;
        
        dialog.classList.add('active');
        this.activeDialog = 'connection';
        
        dialog.dataset.sourceId = sourceId;
        dialog.dataset.targetId = targetId;
        
        const header = dialog.querySelector('.modal-header h3');
        if (header) {
            header.textContent = `Verbindung: ${sourceId} → ${targetId}`;
        }
        
        const labelInput = document.getElementById('connectionLabel');
        const arrowSelect = document.getElementById('connectionArrowType');
        const inverseCheckbox = document.getElementById('createInverseConnection');
        
        if (labelInput) labelInput.value = '';
        if (arrowSelect) arrowSelect.value = '-->';
        if (inverseCheckbox) inverseCheckbox.checked = false;
        
        if (labelInput) labelInput.focus();
    }

    /**
     * Close connection dialog
     */
    closeConnectionDialog() {
        const dialog = document.getElementById('connectionDialog');
        if (dialog) {
            dialog.classList.remove('active');
            this.activeDialog = null;
        }
    }

    /**
     * Create connection from dialog
     */
    createConnectionFromDialog() {
        const dialog = document.getElementById('connectionDialog');
        if (!dialog) return;
        
        const sourceId = dialog.dataset.sourceId;
        const targetId = dialog.dataset.targetId;
        const labelInput = document.getElementById('connectionLabel');
        const arrowSelect = document.getElementById('connectionArrowType');
        const inverseCheckbox = document.getElementById('createInverseConnection');
        
        const connection = {
            from: sourceId,
            to: targetId,
            label: labelInput?.value.trim() || '',
            arrow: arrowSelect?.value || '-->',
            createInverse: inverseCheckbox?.checked || false
        };
        
        this.onConnectionCreate(connection);
        this.closeConnectionDialog();
        this.showNotification('Verbindung erstellt', 'success');
    }

    /**
     * Open style dialog
     * @param {Object} item - Item to style
     * @param {Object} classDefs - Available class definitions
     */
    openStyleDialog(item, classDefs = {}) {
        const dialog = document.getElementById('styleDialog');
        if (!dialog) return;
        
        dialog.classList.add('active');
        this.activeDialog = 'style';
        dialog.dataset.itemId = item.id;
        
        const header = dialog.querySelector('.modal-header h3');
        if (header) {
            header.textContent = `Style: ${item.text || item.id}`;
        }
        
        this.populateStyleForm(item, classDefs);
    }

    /**
     * Close style dialog
     */
    closeStyleDialog() {
        const dialog = document.getElementById('styleDialog');
        if (dialog) {
            dialog.classList.remove('active');
            this.activeDialog = null;
        }
    }

    /**
     * Populate style form
     * @param {Object} item - Item
     * @param {Object} classDefs - Class definitions
     */
    populateStyleForm(item, classDefs) {
        const classSelect = document.getElementById('styleClassSelect');
        if (classSelect) {
            classSelect.innerHTML = '<option value="">Keine Klasse</option>';
            Object.keys(classDefs).forEach(className => {
                const option = document.createElement('option');
                option.value = className;
                option.textContent = className;
                option.selected = item.styleClass === className;
                classSelect.appendChild(option);
            });
        }
        
        const customStyle = item.customStyle || {};
        
        const fillInput = document.getElementById('styleFill');
        const strokeInput = document.getElementById('styleStroke');
        const strokeWidthInput = document.getElementById('styleStrokeWidth');
        const colorInput = document.getElementById('styleColor');
        
        if (fillInput) fillInput.value = customStyle.fill || '';
        if (strokeInput) strokeInput.value = customStyle.stroke || '';
        if (strokeWidthInput) strokeWidthInput.value = customStyle.strokeWidth || '';
        if (colorInput) colorInput.value = customStyle.color || '';
    }

    /**
     * Apply style from dialog
     */
    applyStyleFromDialog() {
        const dialog = document.getElementById('styleDialog');
        if (!dialog) return;
        
        const itemId = dialog.dataset.itemId;
        const classSelect = document.getElementById('styleClassSelect');
        const fillInput = document.getElementById('styleFill');
        const strokeInput = document.getElementById('styleStroke');
        const strokeWidthInput = document.getElementById('styleStrokeWidth');
        const colorInput = document.getElementById('styleColor');
        
        const styleData = {
            itemId,
            styleClass: classSelect?.value || null,
            customStyle: {}
        };
        
        if (fillInput?.value) styleData.customStyle.fill = fillInput.value;
        if (strokeInput?.value) styleData.customStyle.stroke = strokeInput.value;
        if (strokeWidthInput?.value) styleData.customStyle.strokeWidth = strokeWidthInput.value;
        if (colorInput?.value) styleData.customStyle.color = colorInput.value;
        
        if (Object.keys(styleData.customStyle).length === 0) {
            styleData.customStyle = null;
        }
        
        this.onStyleApply(styleData);
        this.closeStyleDialog();
        this.showNotification('Style angewendet', 'success');
    }

    /**
     * Open adopt dialog
     * @param {string} parentId - New parent ID
     * @param {Array} items - All items
     */
    openAdoptDialog(parentId, items) {
        const parent = items.find(i => i.id === parentId);
        if (!parent) return;
        
        const ancestors = new Set();
        let currentId = parentId;
        while (currentId) {
            ancestors.add(currentId);
            const current = items.find(i => i.id === currentId);
            currentId = current?.parentId;
        }
        
        const adoptableItems = items.filter(item => {
            if (item.id === parentId) return false;
            if (ancestors.has(item.id)) return false;
            if (item.parentId === parentId) return false;
            return true;
        });
        
        if (adoptableItems.length === 0) {
            this.showNotification('Keine Elemente zum Adoptieren verfügbar', 'info');
            return;
        }
        
        this.createAdoptDialog(parentId, parent, adoptableItems, items);
    }

    /**
     * Create adopt dialog element
     */
    createAdoptDialog(parentId, parent, adoptableItems, allItems) {
        const existing = document.getElementById('adoptDialog');
        if (existing) existing.remove();
        
        const dialog = document.createElement('div');
        dialog.id = 'adoptDialog';
        dialog.className = 'modal-overlay active';
        
        const parentText = (parent.text || parent.id).split('<br/>')[0];
        
        dialog.innerHTML = `
            <div class="modal-dialog" style="max-width: 400px;">
                <div class="modal-header">
                    <h3>📥 Element adoptieren</h3>
                    <button class="modal-close" onclick="window.dialogManager?.closeAdoptDialog()">✕</button>
                </div>
                <div class="modal-body">
                    <p style="margin-bottom: 12px; color: var(--text-secondary); font-size: 13px;">
                        Wähle ein Element, das zu <strong>"${this.escapeHtml(parentText)}"</strong> verschoben werden soll:
                    </p>
                    <input type="text" id="adoptSearchInput" placeholder="🔍 Suchen..." 
                        style="width: 100%; padding: 8px 12px; margin-bottom: 12px; border: 1px solid var(--border-medium); border-radius: var(--radius-md); font-size: 13px;"
                        oninput="window.dialogManager?.filterAdoptList()">
                    <div id="adoptListContainer" style="max-height: 300px; overflow-y: auto; border: 1px solid var(--border-light); border-radius: var(--radius-md);">
                        ${this.renderAdoptableItems(adoptableItems, allItems, parentId)}
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn" onclick="window.dialogManager?.closeAdoptDialog()">Abbrechen</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(dialog);
        document.getElementById('adoptSearchInput')?.focus();
    }

    /**
     * Render adoptable items list
     */
    renderAdoptableItems(items, allItems, parentId) {
        return items.map(item => {
            const currentParent = allItems.find(p => p.id === item.parentId);
            const parentText = currentParent ? (currentParent.text || currentParent.id).split('<br/>')[0] : 'Root-Ebene';
            const itemText = (item.text || item.id).split('<br/>')[0];
            
            return `
                <div class="adopt-item" data-id="${item.id}" 
                    onclick="window.dialogManager?.executeAdopt('${parentId}', '${item.id}')"
                    style="padding: 10px 12px; cursor: pointer; border-bottom: 1px solid var(--border-light); display: flex; align-items: center; gap: 8px; transition: background 0.15s;"
                    onmouseover="this.style.background='var(--bg-tertiary)'" 
                    onmouseout="this.style.background=''">
                    <span>${item.isContainer ? '📁' : '📄'}</span>
                    <div style="flex: 1; min-width: 0;">
                        <div style="font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                            ${this.escapeHtml(itemText)}
                        </div>
                        <div style="font-size: 11px; color: var(--text-muted);">
                            in: ${this.escapeHtml(parentText)}
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    /**
     * Filter adopt list
     */
    filterAdoptList() {
        const search = document.getElementById('adoptSearchInput')?.value.toLowerCase() || '';
        const items = document.querySelectorAll('#adoptListContainer .adopt-item');
        
        items.forEach(item => {
            const text = item.textContent.toLowerCase();
            item.style.display = text.includes(search) ? 'flex' : 'none';
        });
    }

    /**
     * Close adopt dialog
     */
    closeAdoptDialog() {
        const dialog = document.getElementById('adoptDialog');
        if (dialog) dialog.remove();
    }

    /**
     * Execute adopt action
     */
    executeAdopt(parentId, childId) {
        if (typeof window.changeItemParent === 'function') {
            window.changeItemParent(childId, parentId);
        }
        this.closeAdoptDialog();
        this.showNotification('Element verschoben', 'success');
    }

    /**
     * Open release children dialog
     */
    openReleaseDialog(item, items) {
        if (!item.children || item.children.length === 0) {
            this.showNotification('Dieses Element hat keine Kinder', 'info');
            return;
        }
        
        const children = item.children
            .map(childId => items.find(i => i.id === childId))
            .filter(Boolean);
        
        this.createReleaseDialog(item, children);
    }

    /**
     * Create release children dialog
     */
    createReleaseDialog(parent, children) {
        const existing = document.getElementById('releaseDialog');
        if (existing) existing.remove();
        
        const dialog = document.createElement('div');
        dialog.id = 'releaseDialog';
        dialog.className = 'modal-overlay active';
        
        const parentText = (parent.text || parent.id).split('<br/>')[0];
        
        dialog.innerHTML = `
            <div class="modal-dialog" style="max-width: 400px;">
                <div class="modal-header">
                    <h3>📤 Kinder freigeben</h3>
                    <button class="modal-close" onclick="window.dialogManager?.closeReleaseDialog()">✕</button>
                </div>
                <div class="modal-body">
                    <p style="margin-bottom: 12px; color: var(--text-secondary); font-size: 13px;">
                        Wähle Kinder von <strong>"${this.escapeHtml(parentText)}"</strong>, die zur Root-Ebene verschoben werden sollen:
                    </p>
                    <div id="releaseListContainer" style="max-height: 300px; overflow-y: auto; border: 1px solid var(--border-light); border-radius: var(--radius-md);">
                        ${children.map(child => `
                            <label style="display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-bottom: 1px solid var(--border-light); cursor: pointer;"
                                   onmouseover="this.style.background='var(--bg-tertiary)'" 
                                   onmouseout="this.style.background=''">
                                <input type="checkbox" class="release-checkbox" data-id="${child.id}" style="width: 16px; height: 16px;">
                                <span>${child.isContainer ? '📁' : '📄'}</span>
                                <div style="flex: 1;">
                                    <div style="font-weight: 500;">${this.escapeHtml((child.text || child.id).split('<br/>')[0])}</div>
                                    <div style="font-size: 10px; color: var(--text-muted);">${child.id}</div>
                                </div>
                            </label>
                        `).join('')}
                    </div>
                </div>
                <div class="modal-footer" style="display: flex; gap: 8px; justify-content: flex-end;">
                    <button class="btn" onclick="window.dialogManager?.closeReleaseDialog()">Abbrechen</button>
                    <button class="btn primary" onclick="window.dialogManager?.executeRelease()">Freigeben</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(dialog);
    }

    /**
     * Close release dialog
     */
    closeReleaseDialog() {
        const dialog = document.getElementById('releaseDialog');
        if (dialog) dialog.remove();
    }

    /**
     * Execute release action
     */
    executeRelease() {
        const checkboxes = document.querySelectorAll('#releaseListContainer .release-checkbox:checked');
        const idsToRelease = Array.from(checkboxes).map(cb => cb.dataset.id);
        
        if (idsToRelease.length === 0) {
            this.showNotification('Bitte wählen Sie mindestens ein Element', 'info');
            return;
        }
        
        idsToRelease.forEach(id => {
            if (typeof window.changeItemParent === 'function') {
                window.changeItemParent(id, null);
            }
        });
        
        this.closeReleaseDialog();
        this.showNotification(`${idsToRelease.length} Element(e) freigegeben`, 'success');
    }

    /**
     * Open connection filter dialog
     */
    openConnectionFilterDialog(connections, filters) {
        const dialog = document.getElementById('connectionFilterDialog');
        if (!dialog) return;
        
        dialog.classList.add('active');
        this.activeDialog = 'connectionFilter';
        
        this.populateConnectionTypesList(connections, filters);
        
        const inverseCheckbox = document.getElementById('filterShowInverse');
        if (inverseCheckbox) {
            inverseCheckbox.checked = filters.showInverse || false;
        }
    }

    /**
     * Close connection filter dialog
     */
    closeConnectionFilterDialog() {
        const dialog = document.getElementById('connectionFilterDialog');
        if (dialog) {
            dialog.classList.remove('active');
            this.activeDialog = null;
        }
    }

    /**
     * Populate connection types list
     */
    populateConnectionTypesList(connections, filters) {
        const container = document.getElementById('connectionTypesFilterList');
        if (!container) return;
        
        const types = new Map();
        connections.forEach(conn => {
            const label = conn.label || conn.arrow || 'Ohne Label';
            types.set(label, (types.get(label) || 0) + 1);
        });
        
        if (types.size === 0) {
            container.innerHTML = '<div style="padding: 16px; text-align: center; color: var(--text-muted);">Keine Verbindungen vorhanden</div>';
            return;
        }
        
        const sortedTypes = Array.from(types.entries()).sort((a, b) => b[1] - a[1]);
        
        container.innerHTML = sortedTypes.map(([label, count]) => {
            const isEnabled = !filters.enabledTypes || filters.enabledTypes.size === 0 || filters.enabledTypes.has(label);
            return `
                <label style="display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-bottom: 1px solid var(--border-light); cursor: pointer;">
                    <input type="checkbox" ${isEnabled ? 'checked' : ''} 
                           onchange="window.dialogManager?.toggleConnectionType('${label.replace(/'/g, "\\'")}', this.checked)"
                           style="width: 16px; height: 16px;">
                    <div style="flex: 1;">
                        <span style="font-size: 12px; font-weight: 500;">${this.escapeHtml(label)}</span>
                        <span style="font-size: 10px; color: var(--text-muted); margin-left: 8px;">(${count})</span>
                    </div>
                </label>
            `;
        }).join('');
    }

    /**
     * Toggle connection type filter
     */
    toggleConnectionType(label, enabled) {
        if (typeof window.toggleConnectionType === 'function') {
            window.toggleConnectionType(label, enabled);
        }
    }

    /**
     * Show notification
     */
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        
        const colors = {
            info: 'var(--accent-blue)',
            success: 'var(--accent-green)',
            error: 'var(--accent-red)'
        };
        
        notification.style.cssText = `
            position: fixed;
            top: 70px;
            right: 20px;
            padding: 12px 20px;
            background: ${colors[type] || colors.info};
            color: white;
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-lg);
            z-index: 10000;
            animation: slideIn 0.3s ease-out;
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    /**
     * Escape HTML
     */
    escapeHtml(str) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return String(str || '').replace(/[&<>"']/g, m => map[m]);
    }

    /**
     * Generate Mermaid code
     */
    generateMermaidCode(data) {
        if (window.MermaidGenerator) {
            const generator = new window.MermaidGenerator();
            return generator.generate(data);
        }
        return '// Mermaid Generator not available';
    }

    /**
     * Generate JSON-LD
     */
    generateJsonLD(data) {
        if (window.JsonLDExporter) {
            const exporter = new window.JsonLDExporter();
            return exporter.exportToString(data);
        }
        return JSON.stringify(data, null, 2);
    }

    /**
     * Handle Escape key
     */
    handleEscape() {
        if (this.activeDialog) {
            switch (this.activeDialog) {
                case 'import':
                    this.closeImportDialog();
                    break;
                case 'export':
                    this.closeExportDialog();
                    break;
                case 'connection':
                    this.closeConnectionDialog();
                    break;
                case 'style':
                    this.closeStyleDialog();
                    break;
                case 'connectionFilter':
                    this.closeConnectionFilterDialog();
                    break;
            }
        }
        
        this.closeAdoptDialog();
        this.closeReleaseDialog();
    }
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { DialogManager };
}

// Export for browser
if (typeof window !== 'undefined') {
    window.DialogManager = DialogManager;
}

/**
 * SemAVi - Mermaid Code Generator
 * @module export/mermaid-generator
 * @version 4.8
 * 
 * Generates Mermaid flowchart code from the internal data model
 */

/**
 * Mermaid Code Generator Class
 */
class MermaidGenerator {
    constructor() {
        this.shapes = {
            'rectangle': ['[', ']'],
            'rounded': ['(', ')'],
            'stadium': ['([', '])'],
            'subroutine': ['[[', ']]'],
            'cylindrical': ['[(', ')]'],
            'circle': ['((', '))'],
            'asymmetric': ['>', ']'],
            'rhombus': ['{', '}'],
            'hexagon': ['{{', '}}'],
            'parallelogram': ['[/', '/]'],
            'parallelogram-alt': ['[\\', '\\]'],
            'trapezoid': ['[/', '\\]'],
            'trapezoid-alt': ['[\\', '/]'],
            'double-circle': ['(((', ')))']
        };

        // Shapes requiring new @{} syntax (Mermaid 11+)
        this.newSyntaxShapes = {
            'double-circle': 'dbl-circ',
            'cylindrical': 'cyl',
            'stadium': 'stadium',
            'subroutine': 'subproc',
            'hexagon': 'hex'
        };
    }

    /**
     * Generate complete Mermaid code from data model
     * @param {Object} data - Data model
     * @returns {string} Mermaid flowchart code
     */
    generate(data) {
        const {
            items = [],
            connections = [],
            globalDirection = 'TB',
            initBlock = '',
            styleBlock = '',
            classDefs = {},
            showDetailText = true
        } = data;

        let code = '';

        // Init block
        if (initBlock && initBlock.trim()) {
            code += initBlock.trim() + '\n\n';
        }

        // Flowchart declaration
        code += `flowchart ${globalDirection}\n`;

        // Build item map
        const itemMap = new Map(items.map(item => [item.id, item]));
        const rootItems = items.filter(item => !item.parentId);

        // Generate items
        for (const item of rootItems) {
            code += this.generateItem(item, itemMap, 1, showDetailText);
        }

        // Generate connections
        code += this.generateConnections(connections, itemMap);

        // Generate class definitions
        code += this.generateClassDefs(classDefs);

        // Generate class assignments
        code += this.generateClassAssignments(items);

        // Generate individual styles
        code += this.generateIndividualStyles(items);

        // User-defined style block
        if (styleBlock && styleBlock.trim()) {
            code += '\n    %% Custom Styles\n';
            styleBlock.trim().split('\n').forEach(line => {
                if (line.trim()) {
                    code += `    ${line.trim()}\n`;
                }
            });
        }

        return code;
    }

    /**
     * Generate code for a single item (recursive)
     * @param {Object} item - Item to generate
     * @param {Map} itemMap - Map of all items
     * @param {number} indent - Indentation level
     * @param {boolean} showDetailText - Whether to show detail text
     * @returns {string} Generated code
     */
    generateItem(item, itemMap, indent, showDetailText = true) {
        const spaces = '    '.repeat(indent);
        let code = '';

        if (item.isContainer) {
            // Subgraph
            const title = this.escapeText(item.text || item.id);
            code += `${spaces}subgraph ${item.id}["${title}"]\n`;

            if (item.direction) {
                code += `${spaces}    direction ${item.direction}\n`;
            }

            // Generate children
            const children = (item.children || [])
                .map(childId => itemMap.get(childId))
                .filter(Boolean);

            for (const child of children) {
                code += this.generateItem(child, itemMap, indent + 1, showDetailText);
            }

            code += `${spaces}end\n`;
        } else {
            // Node
            code += `${spaces}${this.formatNode(item, showDetailText)}\n`;
        }

        return code;
    }

    /**
     * Format node with appropriate shape syntax
     * @param {Object} item - Node item
     * @param {boolean} showDetailText - Whether to show detail text
     * @returns {string} Formatted node string
     */
    formatNode(item, showDetailText = true) {
        let displayText = item.title || item.text || '';

        // Append markdown content if present and showDetailText is true
        if (showDetailText && item.markdownContent) {
            displayText = displayText + '<br/>' + item.markdownContent;
        }

        // Show only title if showDetailText is false
        if (!showDetailText && displayText.includes('<br/>')) {
            displayText = displayText.split('<br/>')[0].trim();
        }

        const escapedText = this.escapeText(displayText);

        // Check if new syntax is needed
        if (this.newSyntaxShapes[item.shape]) {
            return `${item.id}@{ shape: ${this.newSyntaxShapes[item.shape]}, label: "${escapedText}" }`;
        }

        // Use classic syntax
        const [open, close] = this.shapes[item.shape] || ['[', ']'];
        return `${item.id}${open}"${escapedText}"${close}`;
    }

    /**
     * Escape text for Mermaid syntax
     * @param {string} text - Text to escape
     * @returns {string} Escaped text
     */
    escapeText(text) {
        return (text || '').replace(/"/g, '\\"');
    }

    /**
     * Generate connections section
     * @param {Array} connections - Array of connections
     * @param {Map} itemMap - Map of all items
     * @returns {string} Generated connections code
     */
    generateConnections(connections, itemMap) {
        if (!connections || connections.length === 0) {
            return '';
        }

        let code = '\n    %% Connections\n';

        for (const conn of connections) {
            const fromItem = itemMap.get(conn.from);
            const toItem = itemMap.get(conn.to);

            if (!fromItem || !toItem) continue;

            const arrow = conn.arrow || '-->';
            const label = conn.label ? `|"${this.escapeText(conn.label)}"|` : '';

            code += `    ${conn.from} ${arrow}${label} ${conn.to}\n`;
        }

        return code;
    }

    /**
     * Generate class definitions
     * @param {Object} classDefs - Class definitions object
     * @returns {string} Generated classDef statements
     */
    generateClassDefs(classDefs) {
        if (!classDefs || Object.keys(classDefs).length === 0) {
            return '';
        }

        let code = '\n    %% Class Definitions\n';

        Object.entries(classDefs).forEach(([className, style]) => {
            const parts = this.styleToPartsArray(style);
            if (parts.length > 0) {
                code += `    classDef ${className} ${parts.join(',')}\n`;
            }
        });

        return code;
    }

    /**
     * Generate class assignments
     * @param {Array} items - All items
     * @returns {string} Generated class assignments
     */
    generateClassAssignments(items) {
        const classAssignments = new Map();

        items.forEach(item => {
            if (item.styleClass) {
                if (!classAssignments.has(item.styleClass)) {
                    classAssignments.set(item.styleClass, []);
                }
                classAssignments.get(item.styleClass).push(item.id);
            }
        });

        if (classAssignments.size === 0) {
            return '';
        }

        let code = '\n    %% Class Assignments\n';

        classAssignments.forEach((nodeIds, className) => {
            code += `    class ${nodeIds.join(',')} ${className}\n`;
        });

        return code;
    }

    /**
     * Generate individual style statements
     * @param {Array} items - All items
     * @returns {string} Generated style statements
     */
    generateIndividualStyles(items) {
        const itemsWithStyle = items.filter(
            item => item.customStyle && Object.keys(item.customStyle).length > 0
        );

        if (itemsWithStyle.length === 0) {
            return '';
        }

        let code = '\n    %% Individual Styles\n';

        itemsWithStyle.forEach(item => {
            const parts = this.styleToPartsArray(item.customStyle);
            if (parts.length > 0) {
                code += `    style ${item.id} ${parts.join(',')}\n`;
            }
        });

        return code;
    }

    /**
     * Convert style object to array of CSS parts
     * @param {Object} style - Style object
     * @returns {Array} Array of CSS parts
     */
    styleToPartsArray(style) {
        const parts = [];

        // Handle common properties first
        if (style.fill) parts.push(`fill:${style.fill}`);
        if (style.stroke) parts.push(`stroke:${style.stroke}`);
        if (style.strokeWidth) parts.push(`stroke-width:${style.strokeWidth}`);
        if (style.color) parts.push(`color:${style.color}`);

        // Handle remaining properties
        const handled = ['fill', 'stroke', 'strokeWidth', 'color'];
        Object.entries(style).forEach(([key, value]) => {
            if (!handled.includes(key)) {
                // Convert camelCase to kebab-case
                const cssKey = key.replace(/([A-Z])/g, '-$1').toLowerCase();
                parts.push(`${cssKey}:${value}`);
            }
        });

        return parts;
    }

    /**
     * Generate minimal code (nodes and connections only)
     * @param {Object} data - Data model
     * @returns {string} Minimal Mermaid code
     */
    generateMinimal(data) {
        const { items = [], connections = [], globalDirection = 'TB' } = data;

        let code = `flowchart ${globalDirection}\n`;

        const itemMap = new Map(items.map(item => [item.id, item]));
        const rootItems = items.filter(item => !item.parentId);

        // Generate items
        for (const item of rootItems) {
            code += this.generateItem(item, itemMap, 1, false);
        }

        // Generate connections (without labels)
        for (const conn of connections) {
            code += `    ${conn.from} --> ${conn.to}\n`;
        }

        return code;
    }
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { MermaidGenerator };
}

// Export for browser
if (typeof window !== 'undefined') {
    window.MermaidGenerator = MermaidGenerator;
}

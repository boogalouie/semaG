/**
 * SemAVi - JSON-LD Export Module
 * @module export/jsonld
 * @version 4.8
 * 
 * Exports the internal data model to JSON-LD format for semantic web applications
 */

/**
 * JSON-LD Exporter Class
 */
class JsonLDExporter {
    constructor() {
        // Default context for JSON-LD
        this.defaultContext = {
            '@vocab': 'http://schema.org/',
            'dcterms': 'http://purl.org/dc/terms/',
            'skos': 'http://www.w3.org/2004/02/skos/core#',
            'bpmn': 'http://www.omg.org/spec/BPMN/20100524/MODEL/',
            'onto': 'http://example.org/ontology#',
            'semavi': 'http://example.org/semavi#',
            'name': 'schema:name',
            'description': 'schema:description',
            'hasPart': 'dcterms:hasPart',
            'isPartOf': 'dcterms:isPartOf',
            'related': 'skos:related',
            'broader': 'skos:broader',
            'narrower': 'skos:narrower'
        };
    }

    /**
     * Export data model to JSON-LD format
     * @param {Object} data - Data model
     * @param {Object} options - Export options
     * @returns {Object} JSON-LD document
     */
    export(data, options = {}) {
        const {
            items = [],
            connections = [],
            globalDirection = 'TB',
            documentMetadata = {}
        } = data;

        const {
            includeStyles = false,
            baseUri = 'http://example.org/semavi/',
            prettyPrint = true
        } = options;

        // Build the JSON-LD document
        const doc = {
            '@context': this.buildContext(options),
            '@type': 'semavi:Diagram',
            '@id': baseUri + 'diagram/' + (documentMetadata.id || this.generateId()),
            'name': documentMetadata.title || 'Unbenanntes Diagramm',
            'description': documentMetadata.description || '',
            'dcterms:creator': documentMetadata.author || '',
            'dcterms:created': documentMetadata.dateCreated || new Date().toISOString(),
            'dcterms:modified': documentMetadata.dateModified || new Date().toISOString(),
            'semavi:version': documentMetadata.version || '1.0',
            'semavi:direction': globalDirection,
            'semavi:nodes': this.exportNodes(items, connections, baseUri, includeStyles),
            'semavi:edges': this.exportEdges(connections, items, baseUri)
        };

        return doc;
    }

    /**
     * Build context with optional extensions
     * @param {Object} options - Options
     * @returns {Object} JSON-LD context
     */
    buildContext(options = {}) {
        const context = { ...this.defaultContext };

        if (options.additionalContext) {
            Object.assign(context, options.additionalContext);
        }

        return context;
    }

    /**
     * Export nodes to JSON-LD format
     * @param {Array} items - All items
     * @param {Array} connections - All connections
     * @param {string} baseUri - Base URI
     * @param {boolean} includeStyles - Whether to include styles
     * @returns {Array} Array of node objects
     */
    exportNodes(items, connections, baseUri, includeStyles) {
        const nodes = [];

        for (const item of items) {
            const node = {
                '@type': item.isContainer ? 'semavi:Subgraph' : 'semavi:Node',
                '@id': baseUri + 'node/' + item.id,
                'semavi:nodeId': item.id,
                'name': this.getNodeName(item),
                'description': this.getNodeDescription(item)
            };

            // Shape (for nodes only)
            if (!item.isContainer && item.shape) {
                node['semavi:shape'] = item.shape;
            }

            // Direction (for subgraphs)
            if (item.isContainer && item.direction) {
                node['semavi:direction'] = item.direction;
            }

            // Parent relationship
            if (item.parentId) {
                node['isPartOf'] = {
                    '@id': baseUri + 'node/' + item.parentId
                };
            }

            // Children
            if (item.children && item.children.length > 0) {
                node['hasPart'] = item.children.map(childId => ({
                    '@id': baseUri + 'node/' + childId
                }));
            }

            // Outgoing connections
            const outgoing = connections.filter(c => c.from === item.id);
            if (outgoing.length > 0) {
                node['semavi:connects'] = outgoing.map(conn => ({
                    '@type': 'semavi:Connection',
                    'semavi:target': { '@id': baseUri + 'node/' + conn.to },
                    'semavi:label': conn.label || '',
                    'semavi:arrowType': conn.arrow || '-->'
                }));
            }

            // Styles (optional)
            if (includeStyles) {
                if (item.styleClass) {
                    node['semavi:styleClass'] = item.styleClass;
                }
                if (item.customStyle) {
                    node['semavi:customStyle'] = item.customStyle;
                }
            }

            // Level
            node['semavi:level'] = item.level || 0;

            nodes.push(node);
        }

        return nodes;
    }

    /**
     * Export edges/connections to JSON-LD format
     * @param {Array} connections - All connections
     * @param {Array} items - All items
     * @param {string} baseUri - Base URI
     * @returns {Array} Array of edge objects
     */
    exportEdges(connections, items, baseUri) {
        const edges = [];
        const itemMap = new Map(items.map(i => [i.id, i]));

        for (const conn of connections) {
            const fromItem = itemMap.get(conn.from);
            const toItem = itemMap.get(conn.to);

            const edge = {
                '@type': 'semavi:Edge',
                '@id': baseUri + 'edge/' + conn.id,
                'semavi:source': { '@id': baseUri + 'node/' + conn.from },
                'semavi:target': { '@id': baseUri + 'node/' + conn.to },
                'semavi:arrowType': conn.arrow || '-->',
                'semavi:connectionType': conn.type || 'arrow'
            };

            // Label with predicate mapping
            if (conn.label) {
                edge['semavi:label'] = conn.label;

                // Try to map to predicate
                const predicate = this.mapLabelToPredicate(conn.label);
                if (predicate) {
                    edge['semavi:predicate'] = predicate;
                }
            }

            // Inverse relationship
            if (conn.isInverse) {
                edge['semavi:isInverse'] = true;
                if (conn.inverseOf) {
                    edge['semavi:inverseOf'] = { '@id': baseUri + 'edge/' + conn.inverseOf };
                }
            }

            edges.push(edge);
        }

        return edges;
    }

    /**
     * Get node name (first line of text)
     * @param {Object} item - Item
     * @returns {string} Node name
     */
    getNodeName(item) {
        const text = item.title || item.text || item.id;
        return text.split('<br/>')[0].trim();
    }

    /**
     * Get node description (remaining text after first line)
     * @param {Object} item - Item
     * @returns {string} Node description
     */
    getNodeDescription(item) {
        const text = item.text || '';
        const parts = text.split('<br/>');
        if (parts.length > 1) {
            return parts.slice(1).join('\n').trim();
        }
        return item.markdownContent || '';
    }

    /**
     * Map label to semantic predicate
     * @param {string} label - Edge label
     * @returns {string|null} Predicate URI or null
     */
    mapLabelToPredicate(label) {
        const predicateMap = {
            // German labels
            'führt zu': 'bpmn:sequenceFlow',
            'fließt zu': 'bpmn:sequenceFlow',
            'ist Teil von': 'dcterms:isPartOf',
            'hat Teil': 'dcterms:hasPart',
            'enthält': 'onto:enthält',
            'erfordert': 'onto:erfordert',
            'basiert auf': 'onto:basiertAuf',
            'referenziert': 'schema:references',
            'folgt auf': 'onto:folgtAuf',
            'entspricht': 'skos:closeMatch',
            'verwandt mit': 'skos:related',
            'siehe auch': 'schema:seeAlso',
            'verursacht': 'onto:causes',
            'wird verursacht von': 'onto:causedBy',

            // Schema labels (camelCase)
            'fuehrtZu': 'bpmn:sequenceFlow',
            'fliesstZu': 'bpmn:sequenceFlow',
            'istTeilVon': 'dcterms:isPartOf',
            'hatTeil': 'dcterms:hasPart',
            'enthaelt': 'onto:enthält',
            'basiertAuf': 'onto:basiertAuf',
            'folgtAuf': 'onto:folgtAuf'
        };

        return predicateMap[label] || null;
    }

    /**
     * Generate unique ID
     * @returns {string} Unique ID
     */
    generateId() {
        return 'doc_' + Date.now().toString(36) + '_' + Math.random().toString(36).substr(2, 9);
    }

    /**
     * Export to JSON string
     * @param {Object} data - Data model
     * @param {Object} options - Export options
     * @returns {string} JSON string
     */
    exportToString(data, options = {}) {
        const doc = this.export(data, options);
        const indent = options.prettyPrint !== false ? 2 : 0;
        return JSON.stringify(doc, null, indent);
    }

    /**
     * Import from JSON-LD format
     * @param {Object|string} input - JSON-LD document or string
     * @returns {Object} Internal data model
     */
    import(input) {
        const doc = typeof input === 'string' ? JSON.parse(input) : input;

        const items = [];
        const connections = [];
        const nodeIdMap = new Map();

        // Import nodes
        if (doc['semavi:nodes']) {
            for (const node of doc['semavi:nodes']) {
                const item = this.importNode(node);
                items.push(item);
                nodeIdMap.set(node['@id'], item.id);
            }
        }

        // Import edges
        if (doc['semavi:edges']) {
            for (const edge of doc['semavi:edges']) {
                const conn = this.importEdge(edge, nodeIdMap);
                if (conn) {
                    connections.push(conn);
                }
            }
        }

        // Fix parent references
        for (const item of items) {
            if (item._parentRef) {
                const parentId = nodeIdMap.get(item._parentRef);
                if (parentId) {
                    item.parentId = parentId;
                }
                delete item._parentRef;
            }
        }

        return {
            items,
            connections,
            globalDirection: doc['semavi:direction'] || 'TB',
            documentMetadata: {
                title: doc['name'] || '',
                author: doc['dcterms:creator'] || '',
                version: doc['semavi:version'] || '1.0',
                dateCreated: doc['dcterms:created'] || null,
                dateModified: doc['dcterms:modified'] || null
            }
        };
    }

    /**
     * Import a single node from JSON-LD
     * @param {Object} node - JSON-LD node
     * @returns {Object} Internal item
     */
    importNode(node) {
        const item = {
            id: node['semavi:nodeId'] || this.extractIdFromUri(node['@id']),
            text: node['name'] || '',
            isContainer: node['@type'] === 'semavi:Subgraph',
            level: node['semavi:level'] || 0,
            shape: node['semavi:shape'] || 'rectangle',
            direction: node['semavi:direction'] || null,
            styleClass: node['semavi:styleClass'] || null,
            customStyle: node['semavi:customStyle'] || null,
            children: []
        };

        // Add description to text
        if (node['description']) {
            item.text = item.text + '<br/>' + node['description'];
        }

        // Store parent reference for later resolution
        if (node['isPartOf'] && node['isPartOf']['@id']) {
            item._parentRef = node['isPartOf']['@id'];
        }

        // Extract children from hasPart
        if (node['hasPart']) {
            const parts = Array.isArray(node['hasPart']) ? node['hasPart'] : [node['hasPart']];
            item.children = parts
                .map(p => this.extractIdFromUri(p['@id']))
                .filter(Boolean);
        }

        return item;
    }

    /**
     * Import a single edge from JSON-LD
     * @param {Object} edge - JSON-LD edge
     * @param {Map} nodeIdMap - Map of URI to node ID
     * @returns {Object|null} Internal connection
     */
    importEdge(edge, nodeIdMap) {
        const sourceUri = edge['semavi:source']?.['@id'];
        const targetUri = edge['semavi:target']?.['@id'];

        if (!sourceUri || !targetUri) return null;

        const fromId = nodeIdMap.get(sourceUri) || this.extractIdFromUri(sourceUri);
        const toId = nodeIdMap.get(targetUri) || this.extractIdFromUri(targetUri);

        return {
            id: this.extractIdFromUri(edge['@id']) || 'conn_' + Date.now(),
            from: fromId,
            to: toId,
            arrow: edge['semavi:arrowType'] || '-->',
            type: edge['semavi:connectionType'] || 'arrow',
            label: edge['semavi:label'] || '',
            isInverse: edge['semavi:isInverse'] || false
        };
    }

    /**
     * Extract ID from URI
     * @param {string} uri - Full URI
     * @returns {string} Extracted ID
     */
    extractIdFromUri(uri) {
        if (!uri) return '';
        const parts = uri.split('/');
        return parts[parts.length - 1];
    }
}

/**
 * Export to native JSON format (simpler, non-LD)
 */
class JsonExporter {
    /**
     * Export data model to native JSON format
     * @param {Object} data - Data model
     * @returns {Object} JSON document
     */
    export(data) {
        return {
            version: '4.8',
            exportedAt: new Date().toISOString(),
            metadata: data.documentMetadata || {},
            globalDirection: data.globalDirection || 'TB',
            initBlock: data.initBlock || '',
            styleBlock: data.styleBlock || '',
            classDefs: data.classDefs || {},
            items: data.items || [],
            connections: data.connections || []
        };
    }

    /**
     * Export to JSON string
     * @param {Object} data - Data model
     * @param {boolean} prettyPrint - Whether to pretty print
     * @returns {string} JSON string
     */
    exportToString(data, prettyPrint = true) {
        const doc = this.export(data);
        return JSON.stringify(doc, null, prettyPrint ? 2 : 0);
    }

    /**
     * Import from native JSON format
     * @param {Object|string} input - JSON document or string
     * @returns {Object} Data model
     */
    import(input) {
        const doc = typeof input === 'string' ? JSON.parse(input) : input;

        return {
            items: doc.items || [],
            connections: doc.connections || [],
            globalDirection: doc.globalDirection || 'TB',
            initBlock: doc.initBlock || '',
            styleBlock: doc.styleBlock || '',
            classDefs: doc.classDefs || {},
            documentMetadata: doc.metadata || {}
        };
    }
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { JsonLDExporter, JsonExporter };
}

// Export for browser
if (typeof window !== 'undefined') {
    window.JsonLDExporter = JsonLDExporter;
    window.JsonExporter = JsonExporter;
}

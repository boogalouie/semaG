/**
 * SemAVi - Main Application
 * @module core/app
 * @version 4.8
 * 
 * Main application entry point that coordinates all modules
 */

/**
 * SemAVi Application Class
 */
class SemAViApp {
    constructor(options = {}) {
        // Core data
        this.hierarchyData = [];
        this.connections = [];
        this.globalDirection = 'TB';
        this.initBlock = '';
        this.styleBlock = '';
        this.classDefs = {};
        this.styleClasses = {};
        
        // UI State
        this.selectedItemId = null;
        this.expandedItems = new Set();
        this.searchQuery = '';
        
        // Connection mode
        this.connectionMode = false;
        this.connectionSource = null;
        
        // Focus mode
        this.focusMode = false;
        this.focusItemId = null;
        
        // Filters
        this.connectionFilters = {
            showInverse: false,
            enabledTypes: new Set()
        };
        this.displayFilters = {
            showDetailText: true
        };
        
        // Config
        this.flowchartConfig = {
            nodeSpacing: 50,
            rankSpacing: 50,
            curve: 'basis'
        };
        
        // Document metadata
        this.documentMetadata = {
            title: '',
            author: '',
            version: '1.0',
            dateCreated: null,
            dateModified: null
        };
        
        // Version history
        this.versionHistory = [];
        this.currentVersionIndex = -1;
        
        // Item counter
        this.itemCounter = 1;
        
        // Storage key
        this.storageKey = 'semavi_v1_state';
        
        // Module instances
        this.parser = null;
        this.generator = null;
        this.treeUI = null;
        this.previewUI = null;
        this.dialogManager = null;
        this.historyManager = null;
        
        // Mermaid instance
        this.mermaid = options.mermaid || window.mermaid;
        
        // Initialize
        this.init();
    }

    /**
     * Initialize the application
     */
    init() {
        // Initialize Mermaid
        if (this.mermaid) {
            this.mermaid.initialize({
                startOnLoad: false,
                theme: 'default',
                securityLevel: 'loose'
            });
        }
        
        // Initialize modules
        this.initModules();
        
        // Setup event listeners
        this.setupEventListeners();
        
        // Load saved state
        if (this.loadFromLocalStorage()) {
            console.log('✅ Loaded state from localStorage');
        } else {
            this.saveVersion('Initialisierung');
        }
        
        // Initial render
        this.updateDisplay();
        
        // Setup auto-save
        setInterval(() => this.saveToLocalStorage(), 5000);
        window.addEventListener('beforeunload', () => this.saveToLocalStorage());
        
        // Setup file drag & drop
        this.setupFileDragDrop();
        
        console.log('🚀 SemAVi initialized');
    }

    /**
     * Initialize module instances
     */
    initModules() {
        // Parser
        if (window.UnifiedMermaidParser) {
            this.parser = new window.UnifiedMermaidParser();
        }
        
        // Generator
        if (window.MermaidGenerator) {
            this.generator = new window.MermaidGenerator();
        }
        
        // Tree UI
        if (window.TreeUI) {
            this.treeUI = new window.TreeUI({
                containerId: 'hierarchyContainer',
                onSelect: (id) => this.selectItem(id),
                onExpand: (id, expanded) => this.handleExpand(id, expanded),
                onDelete: (id) => this.deleteItem(id),
                onAddChild: (id) => id ? this.addChildItem(id) : this.addRootItem(),
                onUpdateProperty: (id, prop, value) => this.updateItemProperty(id, prop, value)
            });
        }
        
        // Preview UI
        if (window.PreviewUI) {
            this.previewUI = new window.PreviewUI({
                containerId: 'previewContent',
                viewportId: 'previewViewport',
                mermaid: this.mermaid,
                onNodeClick: (id, node, e) => this.handleNodeClick(id, node, e),
                onNodeDoubleClick: (id, node, e) => this.handleNodeDoubleClick(id, node, e),
                onZoomChange: (zoom) => this.handleZoomChange(zoom)
            });
        }
        
        // Dialog Manager
        if (window.DialogManager) {
            this.dialogManager = new window.DialogManager({
                onImport: (content, format) => this.importContent(content, format),
                onExport: (data, format) => this.exportContent(format),
                onConnectionCreate: (conn) => this.createConnection(conn),
                onStyleApply: (styleData) => this.applyStyle(styleData)
            });
            window.dialogManager = this.dialogManager;
        }
        
        // History Manager
        if (window.HistoryManager) {
            this.historyManager = new window.HistoryManager({
                maxVersions: 50,
                onRestore: (state) => this.restoreState(state)
            });
        }
        
        // Export to window for global access
        window.semavi = this;
        window.treeUI = this.treeUI;
    }

    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyDown(e));
        
        // Tab switching
        document.querySelectorAll('.content-tab').forEach(tab => {
            tab.addEventListener('click', () => this.switchTab(tab.dataset.tab));
        });
        
        // Search input
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => this.handleSearch(e.target.value));
        }
        
        // Global direction select
        const directionSelect = document.getElementById('globalDirection');
        if (directionSelect) {
            directionSelect.addEventListener('change', (e) => {
                this.globalDirection = e.target.value;
                this.saveVersion('Richtung geändert');
                this.updateDisplay();
            });
        }
        
        // Init block editor
        const initBlockEditor = document.getElementById('initBlockEditor');
        if (initBlockEditor) {
            initBlockEditor.addEventListener('change', (e) => {
                this.initBlock = e.target.value;
                this.saveVersion('Init-Block geändert');
                this.updateDisplay();
            });
        }
        
        // Style block editor
        const styleBlockEditor = document.getElementById('styleBlockEditor');
        if (styleBlockEditor) {
            styleBlockEditor.addEventListener('change', (e) => {
                this.styleBlock = e.target.value;
                this.saveVersion('Style-Block geändert');
                this.updateDisplay();
            });
        }
    }

    /**
     * Handle keyboard shortcuts
     * @param {KeyboardEvent} e - Keyboard event
     */
    handleKeyDown(e) {
        // Ignore if typing in input
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') {
            return;
        }
        
        // Ctrl+Z: Undo
        if (e.ctrlKey && e.key === 'z') {
            e.preventDefault();
            this.undo();
        }
        
        // Ctrl+Y: Redo
        if (e.ctrlKey && e.key === 'y') {
            e.preventDefault();
            this.redo();
        }
        
        // Delete: Delete selected item
        if (e.key === 'Delete' && this.selectedItemId) {
            this.deleteItem(this.selectedItemId);
        }
        
        // Escape: Cancel modes
        if (e.key === 'Escape') {
            if (this.connectionMode) {
                this.cancelConnection();
            } else if (this.focusMode) {
                this.exitFocusMode();
            } else if (this.dialogManager) {
                this.dialogManager.handleEscape();
            }
        }
        
        // N: New root item
        if (e.key === 'n' && !e.ctrlKey) {
            this.addRootItem();
        }
        
        // Arrow keys: Pan preview
        const panStep = 50;
        if (this.previewUI) {
            if (e.key === 'ArrowUp') {
                e.preventDefault();
                this.previewUI.panY += panStep;
                this.previewUI.updateTransform();
            }
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                this.previewUI.panY -= panStep;
                this.previewUI.updateTransform();
            }
            if (e.key === 'ArrowLeft') {
                e.preventDefault();
                this.previewUI.panX += panStep;
                this.previewUI.updateTransform();
            }
            if (e.key === 'ArrowRight') {
                e.preventDefault();
                this.previewUI.panX -= panStep;
                this.previewUI.updateTransform();
            }
        }
        
        // R: Reset zoom
        if (e.key === 'r' || e.key === 'R') {
            e.preventDefault();
            if (this.previewUI) {
                this.previewUI.resetZoom();
            }
        }
        
        // +/-: Zoom
        if (e.key === '+' || e.key === '=') {
            e.preventDefault();
            if (this.previewUI) {
                this.previewUI.zoomIn();
            }
        }
        if (e.key === '-' || e.key === '_') {
            e.preventDefault();
            if (this.previewUI) {
                this.previewUI.zoomOut();
            }
        }
    }

    // =====================================
    // CRUD Operations
    // =====================================

    /**
     * Generate unique item ID
     * @returns {string} Unique ID
     */
    generateItemId() {
        while (this.hierarchyData.some(item => item.id === `N${this.itemCounter}`)) {
            this.itemCounter++;
        }
        return `N${this.itemCounter++}`;
    }

    /**
     * Add root item
     */
    addRootItem() {
        const id = this.generateItemId();
        const item = {
            id,
            text: 'Neues Element',
            parentId: null,
            level: 0,
            isContainer: false,
            shape: 'rectangle',
            direction: null,
            children: [],
            customStyle: null
        };
        
        this.hierarchyData.push(item);
        this.selectedItemId = id;
        this.expandedItems.add(id);
        
        this.saveVersion(`Root-Element ${id} hinzugefügt`);
        this.updateDisplay();
    }

    /**
     * Add child item
     * @param {string} parentId - Parent item ID
     */
    addChildItem(parentId) {
        const parent = this.hierarchyData.find(item => item.id === parentId);
        if (!parent) return;
        
        if (!parent.isContainer) {
            parent.isContainer = true;
        }
        
        const id = this.generateItemId();
        const item = {
            id,
            text: `Item ${id.substring(1)}`,
            parentId,
            level: parent.level + 1,
            isContainer: false,
            shape: 'rectangle',
            direction: null,
            children: [],
            customStyle: null
        };
        
        parent.children.push(id);
        this.hierarchyData.push(item);
        this.selectedItemId = id;
        this.expandedItems.add(parentId);
        this.expandedItems.add(id);
        
        this.saveVersion(`Kind-Element ${id} zu ${parentId} hinzugefügt`);
        this.updateDisplay();
    }

    /**
     * Delete item and descendants
     * @param {string} itemId - Item ID to delete
     */
    deleteItem(itemId) {
        const item = this.hierarchyData.find(i => i.id === itemId);
        if (!item) return;
        
        // Collect descendants
        const toDelete = new Set([itemId]);
        const collectDescendants = (id) => {
            const parent = this.hierarchyData.find(i => i.id === id);
            if (parent && parent.children) {
                parent.children.forEach(childId => {
                    toDelete.add(childId);
                    collectDescendants(childId);
                });
            }
        };
        collectDescendants(itemId);
        
        // Remove from parent
        if (item.parentId) {
            const parent = this.hierarchyData.find(i => i.id === item.parentId);
            if (parent) {
                parent.children = parent.children.filter(id => id !== itemId);
                if (parent.children.length === 0) {
                    parent.isContainer = false;
                }
            }
        }
        
        // Remove items and connections
        this.hierarchyData = this.hierarchyData.filter(i => !toDelete.has(i.id));
        this.connections = this.connections.filter(c => !toDelete.has(c.from) && !toDelete.has(c.to));
        
        if (this.selectedItemId === itemId) {
            this.selectedItemId = null;
        }
        
        this.saveVersion(`Element ${itemId} gelöscht`);
        this.updateDisplay();
    }

    /**
     * Update item property
     * @param {string} itemId - Item ID
     * @param {string} property - Property name
     * @param {any} value - New value
     */
    updateItemProperty(itemId, property, value) {
        const item = this.hierarchyData.find(i => i.id === itemId);
        if (!item) return;
        
        item[property] = value;
        this.saveVersion(`${property} von ${itemId} aktualisiert`);
        this.updateDisplay();
    }

    /**
     * Select item
     * @param {string} itemId - Item ID
     */
    selectItem(itemId) {
        this.selectedItemId = itemId;
        this.expandedItems.add(itemId);
        
        // Expand parent chain
        const item = this.hierarchyData.find(i => i.id === itemId);
        let parentId = item?.parentId;
        while (parentId) {
            this.expandedItems.add(parentId);
            const parent = this.hierarchyData.find(i => i.id === parentId);
            parentId = parent?.parentId;
        }
        
        this.updateDisplay();
        
        // Highlight in preview
        if (this.previewUI) {
            this.previewUI.highlightSelectedNode(itemId);
        }
    }

    /**
     * Handle expand toggle
     * @param {string} itemId - Item ID
     * @param {boolean} expanded - Whether expanded
     */
    handleExpand(itemId, expanded) {
        if (expanded) {
            this.expandedItems.add(itemId);
        } else {
            this.expandedItems.delete(itemId);
        }
        this.updateDisplay();
    }

    // =====================================
    // Connection Management
    // =====================================

    /**
     * Start connection mode
     * @param {string} sourceId - Source node ID
     */
    startConnection(sourceId) {
        this.connectionMode = true;
        this.connectionSource = sourceId;
        document.body.classList.add('connection-mode-active');
        
        const statusBar = document.getElementById('connectionStatusBar');
        const statusText = document.getElementById('connectionStatusText');
        const sourceItem = this.hierarchyData.find(i => i.id === sourceId);
        
        if (statusText) {
            statusText.textContent = `Verbindung von "${sourceItem?.text || sourceId}" - Klick auf Ziel`;
        }
        if (statusBar) {
            statusBar.classList.add('active');
        }
    }

    /**
     * Cancel connection mode
     */
    cancelConnection() {
        this.connectionMode = false;
        this.connectionSource = null;
        document.body.classList.remove('connection-mode-active');
        
        const statusBar = document.getElementById('connectionStatusBar');
        if (statusBar) {
            statusBar.classList.remove('active');
        }
    }

    /**
     * Create connection
     * @param {Object} connData - Connection data
     */
    createConnection(connData) {
        const connection = {
            id: `conn_${Date.now()}`,
            from: connData.from,
            to: connData.to,
            type: 'arrow',
            arrow: connData.arrow || '-->',
            label: connData.label || '',
            isInverse: false
        };
        
        this.connections.push(connection);
        
        // Create inverse if requested
        if (connData.createInverse && connData.arrow !== '<-->') {
            const inverseConnection = {
                id: `conn_${Date.now()}_inv`,
                from: connData.to,
                to: connData.from,
                type: 'arrow',
                arrow: connData.arrow,
                label: this.getInverseLabel(connData.label),
                isInverse: true,
                inverseOf: connection.id
            };
            this.connections.push(inverseConnection);
        }
        
        this.cancelConnection();
        this.saveVersion(`Verbindung ${connData.from} → ${connData.to} erstellt`);
        this.updateDisplay();
    }

    /**
     * Delete connection
     * @param {string} connId - Connection ID
     */
    deleteConnection(connId) {
        // Also delete inverse
        const conn = this.connections.find(c => c.id === connId);
        if (conn) {
            this.connections = this.connections.filter(c => 
                c.id !== connId && 
                c.inverseOf !== connId &&
                (conn.inverseOf ? c.id !== conn.inverseOf : true)
            );
        }
        
        this.saveVersion(`Verbindung gelöscht`);
        this.updateDisplay();
    }

    /**
     * Get inverse label
     * @param {string} label - Original label
     * @returns {string} Inverse label
     */
    getInverseLabel(label) {
        const inverseMap = {
            'führt zu': 'wird erreicht von',
            'ist Teil von': 'enthält',
            'enthält': 'ist Teil von',
            'erfordert': 'wird erfordert von',
            'basiert auf': 'ist Basis für'
        };
        return inverseMap[label] || (label ? `inv: ${label}` : '');
    }

    // =====================================
    // Import/Export
    // =====================================

    /**
     * Import content
     * @param {string} content - Content to import
     * @param {string} format - Format (auto, mermaid, json, jsonld)
     */
    importContent(content, format) {
        try {
            if (format === 'auto') {
                // Auto-detect format
                if (content.trim().startsWith('{')) {
                    const parsed = JSON.parse(content);
                    if (parsed['@context'] || parsed['semavi:nodes']) {
                        format = 'jsonld';
                    } else {
                        format = 'json';
                    }
                } else {
                    format = 'mermaid';
                }
            }
            
            switch (format) {
                case 'mermaid':
                    this.importMermaid(content);
                    break;
                case 'json':
                    this.importJson(content);
                    break;
                case 'jsonld':
                    this.importJsonLD(content);
                    break;
            }
            
            this.saveVersion(`Import: ${format}`);
            this.updateDisplay();
        } catch (err) {
            console.error('Import error:', err);
            throw err;
        }
    }

    /**
     * Import Mermaid code
     * @param {string} code - Mermaid code
     */
    importMermaid(code) {
        if (!this.parser) {
            throw new Error('Parser not available');
        }
        
        const result = this.parser.parse(code);
        
        this.hierarchyData = result.items || [];
        this.connections = result.connections || [];
        this.globalDirection = result.globalDirection || 'TB';
        this.initBlock = result.initBlock || '';
        this.classDefs = result.classDefs || {};
        
        // Update item counter
        const maxNum = this.hierarchyData.reduce((max, item) => {
            const match = item.id.match(/^N(\d+)$/);
            return match ? Math.max(max, parseInt(match[1])) : max;
        }, 0);
        this.itemCounter = maxNum + 1;
    }

    /**
     * Import JSON
     * @param {string} content - JSON content
     */
    importJson(content) {
        const data = JSON.parse(content);
        
        this.hierarchyData = data.items || [];
        this.connections = data.connections || [];
        this.globalDirection = data.globalDirection || 'TB';
        this.initBlock = data.initBlock || '';
        this.styleBlock = data.styleBlock || '';
        this.classDefs = data.classDefs || {};
        
        if (data.metadata) {
            this.documentMetadata = data.metadata;
        }
    }

    /**
     * Import JSON-LD
     * @param {string} content - JSON-LD content
     */
    importJsonLD(content) {
        if (window.JsonLDExporter) {
            const exporter = new window.JsonLDExporter();
            const data = exporter.import(content);
            
            this.hierarchyData = data.items || [];
            this.connections = data.connections || [];
            this.globalDirection = data.globalDirection || 'TB';
            
            if (data.documentMetadata) {
                this.documentMetadata = data.documentMetadata;
            }
        } else {
            this.importJson(content);
        }
    }

    /**
     * Export content
     * @param {string} format - Export format
     */
    exportContent(format) {
        const data = this.getExportData();
        let content = '';
        let filename = '';
        let mimeType = 'text/plain';
        
        switch (format) {
            case 'mermaid':
                content = this.generateMermaidCode();
                filename = 'diagram.mmd';
                break;
            case 'json':
                content = JSON.stringify(data, null, 2);
                filename = 'diagram.json';
                mimeType = 'application/json';
                break;
            case 'jsonld':
                if (window.JsonLDExporter) {
                    const exporter = new window.JsonLDExporter();
                    content = exporter.exportToString(data);
                } else {
                    content = JSON.stringify(data, null, 2);
                }
                filename = 'diagram.jsonld';
                mimeType = 'application/ld+json';
                break;
        }
        
        this.downloadFile(content, filename, mimeType);
    }

    /**
     * Get export data
     * @returns {Object} Export data
     */
    getExportData() {
        return {
            items: this.hierarchyData,
            connections: this.connections,
            globalDirection: this.globalDirection,
            initBlock: this.initBlock,
            styleBlock: this.styleBlock,
            classDefs: this.classDefs,
            documentMetadata: this.documentMetadata
        };
    }

    /**
     * Download file
     * @param {string} content - File content
     * @param {string} filename - File name
     * @param {string} mimeType - MIME type
     */
    downloadFile(content, filename, mimeType) {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    // =====================================
    // Display Updates
    // =====================================

    /**
     * Update all displays
     */
    updateDisplay() {
        this.updateHierarchyTree();
        this.updateMermaidCode();
        this.updatePreview();
        this.updateStatistics();
        this.updateJsonLD();
    }

    /**
     * Update hierarchy tree
     */
    updateHierarchyTree() {
        if (this.treeUI) {
            this.treeUI.setSelectedItem(this.selectedItemId);
            this.treeUI.setExpandedItems(this.expandedItems);
            this.treeUI.setSearchQuery(this.searchQuery);
            this.treeUI.render(this.hierarchyData, this.connections);
        }
    }

    /**
     * Generate and update Mermaid code
     */
    updateMermaidCode() {
        const code = this.generateMermaidCode();
        const editor = document.getElementById('mermaidEditor');
        if (editor) {
            editor.value = code;
        }
    }

    /**
     * Generate Mermaid code
     * @returns {string} Mermaid code
     */
    generateMermaidCode() {
        const data = {
            items: this.hierarchyData,
            connections: this.getFilteredConnections(),
            globalDirection: this.globalDirection,
            initBlock: this.initBlock,
            styleBlock: this.styleBlock,
            classDefs: this.classDefs,
            showDetailText: this.displayFilters.showDetailText
        };
        
        if (this.generator) {
            return this.generator.generate(data);
        } else if (this.parser) {
            return this.parser.generate(data);
        }
        
        return '';
    }

    /**
     * Get filtered connections
     * @returns {Array} Filtered connections
     */
    getFilteredConnections() {
        let filtered = [...this.connections];
        
        // Filter inverse connections
        if (!this.connectionFilters.showInverse) {
            filtered = filtered.filter(c => !c.isInverse);
        }
        
        // Filter by enabled types
        if (this.connectionFilters.enabledTypes.size > 0) {
            filtered = filtered.filter(c => {
                const label = c.label || c.arrow || 'Ohne Label';
                return this.connectionFilters.enabledTypes.has(label);
            });
        }
        
        return filtered;
    }

    /**
     * Update preview
     */
    updatePreview() {
        const code = document.getElementById('mermaidEditor')?.value || '';
        
        if (this.previewUI) {
            this.previewUI.render(code);
        }
    }

    /**
     * Update statistics display
     */
    updateStatistics() {
        const itemsEl = document.getElementById('totalItems');
        const connEl = document.getElementById('totalConnections');
        
        if (itemsEl) itemsEl.textContent = this.hierarchyData.length;
        if (connEl) connEl.textContent = this.connections.length;
    }

    /**
     * Update JSON-LD display
     */
    updateJsonLD() {
        const editor = document.getElementById('jsonldEditor');
        if (!editor) return;
        
        const data = this.getExportData();
        
        if (window.JsonLDExporter) {
            const exporter = new window.JsonLDExporter();
            editor.value = exporter.exportToString(data);
        } else {
            editor.value = JSON.stringify(data, null, 2);
        }
    }

    // =====================================
    // Event Handlers
    // =====================================

    /**
     * Handle node click in preview
     * @param {string} nodeId - Node ID
     * @param {Element} node - SVG node element
     * @param {MouseEvent} e - Mouse event
     */
    handleNodeClick(nodeId, node, e) {
        if (this.connectionMode && this.connectionSource) {
            if (nodeId !== this.connectionSource) {
                if (this.dialogManager) {
                    this.dialogManager.openConnectionDialog(this.connectionSource, nodeId);
                } else {
                    this.createConnection({
                        from: this.connectionSource,
                        to: nodeId,
                        arrow: '-->',
                        label: ''
                    });
                }
            }
        } else {
            this.selectItem(nodeId);
        }
    }

    /**
     * Handle node double click in preview
     * @param {string} nodeId - Node ID
     * @param {Element} node - SVG node element
     * @param {MouseEvent} e - Mouse event
     */
    handleNodeDoubleClick(nodeId, node, e) {
        // Open node popup or start connection
        this.showNodePopup(nodeId, e.clientX, e.clientY);
    }

    /**
     * Show node popup
     * @param {string} nodeId - Node ID
     * @param {number} x - X position
     * @param {number} y - Y position
     */
    showNodePopup(nodeId, x, y) {
        const popup = document.getElementById('nodePopup');
        if (!popup) return;
        
        const item = this.hierarchyData.find(i => i.id === nodeId);
        if (!item) return;
        
        // Update popup content
        const title = popup.querySelector('.node-popup-title');
        if (title) {
            title.textContent = (item.text || item.id).split('<br/>')[0];
        }
        
        popup.dataset.nodeId = nodeId;
        
        // Position popup
        const popupWidth = 180;
        const popupHeight = 200;
        
        let posX = x + 10;
        let posY = y - 30;
        
        if (posX + popupWidth > window.innerWidth) {
            posX = x - popupWidth - 10;
        }
        if (posY + popupHeight > window.innerHeight) {
            posY = window.innerHeight - popupHeight - 10;
        }
        if (posY < 60) {
            posY = 60;
        }
        
        popup.style.left = posX + 'px';
        popup.style.top = posY + 'px';
        popup.classList.add('active');
    }

    /**
     * Handle zoom change
     * @param {number} zoom - New zoom level
     */
    handleZoomChange(zoom) {
        // Could update UI or save state
    }

    /**
     * Handle search
     * @param {string} query - Search query
     */
    handleSearch(query) {
        this.searchQuery = query;
        this.updateHierarchyTree();
    }

    /**
     * Switch content tab
     * @param {string} tabName - Tab name
     */
    switchTab(tabName) {
        document.querySelectorAll('.content-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.tab === tabName);
        });
        
        document.querySelectorAll('.content-panel').forEach(panel => {
            panel.classList.toggle('active', panel.id === `${tabName}Panel`);
        });
        
        if (tabName === 'preview') {
            this.updatePreview();
        }
    }

    // =====================================
    // Version History
    // =====================================

    /**
     * Save version
     * @param {string} description - Version description
     */
    saveVersion(description) {
        const state = {
            hierarchyData: JSON.parse(JSON.stringify(this.hierarchyData)),
            connections: JSON.parse(JSON.stringify(this.connections)),
            globalDirection: this.globalDirection,
            initBlock: this.initBlock,
            styleBlock: this.styleBlock,
            classDefs: JSON.parse(JSON.stringify(this.classDefs)),
            timestamp: new Date().toISOString(),
            description
        };
        
        // Remove future versions if we're not at the end
        if (this.currentVersionIndex < this.versionHistory.length - 1) {
            this.versionHistory = this.versionHistory.slice(0, this.currentVersionIndex + 1);
        }
        
        this.versionHistory.push(state);
        this.currentVersionIndex = this.versionHistory.length - 1;
        
        // Limit history size
        if (this.versionHistory.length > 50) {
            this.versionHistory.shift();
            this.currentVersionIndex--;
        }
        
        this.updateButtons();
    }

    /**
     * Undo
     */
    undo() {
        if (this.currentVersionIndex > 0) {
            this.currentVersionIndex--;
            this.restoreVersion(this.currentVersionIndex);
        }
    }

    /**
     * Redo
     */
    redo() {
        if (this.currentVersionIndex < this.versionHistory.length - 1) {
            this.currentVersionIndex++;
            this.restoreVersion(this.currentVersionIndex);
        }
    }

    /**
     * Restore version
     * @param {number} index - Version index
     */
    restoreVersion(index) {
        const version = this.versionHistory[index];
        if (!version) return;
        
        this.hierarchyData = JSON.parse(JSON.stringify(version.hierarchyData));
        this.connections = JSON.parse(JSON.stringify(version.connections));
        this.globalDirection = version.globalDirection;
        this.initBlock = version.initBlock;
        this.styleBlock = version.styleBlock;
        this.classDefs = JSON.parse(JSON.stringify(version.classDefs));
        
        this.updateDisplay();
        this.updateButtons();
    }

    /**
     * Update undo/redo buttons
     */
    updateButtons() {
        const undoBtn = document.getElementById('undoBtn');
        const redoBtn = document.getElementById('redoBtn');
        
        if (undoBtn) undoBtn.disabled = this.currentVersionIndex <= 0;
        if (redoBtn) redoBtn.disabled = this.currentVersionIndex >= this.versionHistory.length - 1;
    }

    // =====================================
    // Local Storage
    // =====================================

    /**
     * Save to local storage
     */
    saveToLocalStorage() {
        try {
            const state = {
                hierarchyData: this.hierarchyData,
                connections: this.connections,
                globalDirection: this.globalDirection,
                initBlock: this.initBlock,
                styleBlock: this.styleBlock,
                classDefs: this.classDefs,
                flowchartConfig: this.flowchartConfig,
                expandedItems: Array.from(this.expandedItems),
                selectedItemId: this.selectedItemId,
                documentMetadata: this.documentMetadata,
                versionHistory: this.versionHistory.slice(-10),
                currentVersionIndex: Math.min(this.currentVersionIndex, 9),
                savedAt: new Date().toISOString()
            };
            
            if (this.previewUI) {
                const previewState = this.previewUI.getState();
                state.zoomLevel = previewState.zoomLevel;
                state.panX = previewState.panX;
                state.panY = previewState.panY;
                state.interactionMode = previewState.interactionMode;
            }
            
            localStorage.setItem(this.storageKey, JSON.stringify(state));
        } catch (e) {
            console.error('Failed to save to localStorage:', e);
        }
    }

    /**
     * Load from local storage
     * @returns {boolean} Whether state was loaded
     */
    loadFromLocalStorage() {
        try {
            const saved = localStorage.getItem(this.storageKey);
            if (!saved) return false;
            
            const state = JSON.parse(saved);
            
            this.hierarchyData = state.hierarchyData || [];
            this.connections = state.connections || [];
            this.globalDirection = state.globalDirection || 'TB';
            if (this.globalDirection === 'TD') this.globalDirection = 'TB';
            this.initBlock = state.initBlock || '';
            this.styleBlock = state.styleBlock || '';
            this.classDefs = state.classDefs || {};
            this.flowchartConfig = state.flowchartConfig || { nodeSpacing: 50, rankSpacing: 50, curve: 'basis' };
            this.expandedItems = new Set(state.expandedItems || []);
            this.selectedItemId = state.selectedItemId || null;
            this.documentMetadata = state.documentMetadata || {};
            this.versionHistory = state.versionHistory || [];
            this.currentVersionIndex = state.currentVersionIndex || -1;
            
            // Restore preview state
            if (this.previewUI && state.zoomLevel) {
                this.previewUI.setState({
                    zoomLevel: state.zoomLevel,
                    panX: state.panX,
                    panY: state.panY,
                    interactionMode: state.interactionMode
                });
                this.previewUI.isFirstRender = false;
            }
            
            // Update UI elements
            const globalDirEl = document.getElementById('globalDirection');
            if (globalDirEl) globalDirEl.value = this.globalDirection;
            
            const initBlockEl = document.getElementById('initBlockEditor');
            if (initBlockEl) initBlockEl.value = this.initBlock;
            
            const styleBlockEl = document.getElementById('styleBlockEditor');
            if (styleBlockEl) styleBlockEl.value = this.styleBlock;
            
            // Update item counter
            const maxNum = this.hierarchyData.reduce((max, item) => {
                const match = item.id.match(/^N(\d+)$/);
                return match ? Math.max(max, parseInt(match[1])) : max;
            }, 0);
            this.itemCounter = maxNum + 1;
            
            return this.hierarchyData.length > 0 || this.connections.length > 0;
        } catch (e) {
            console.error('Failed to load from localStorage:', e);
            return false;
        }
    }

    /**
     * Clear local storage
     */
    clearLocalStorage() {
        if (!confirm('Möchten Sie alle Daten zurücksetzen?')) return;
        if (!confirm('⚠️ WARNUNG: Diese Aktion kann nicht rückgängig gemacht werden!')) return;
        
        localStorage.removeItem(this.storageKey);
        
        this.hierarchyData = [];
        this.connections = [];
        this.globalDirection = 'TB';
        this.initBlock = '';
        this.styleBlock = '';
        this.classDefs = {};
        this.selectedItemId = null;
        this.expandedItems = new Set();
        this.versionHistory = [];
        this.currentVersionIndex = -1;
        
        this.saveVersion('Daten zurückgesetzt');
        this.updateDisplay();
        
        this.showNotification('Alle Daten wurden zurückgesetzt', 'info');
    }

    // =====================================
    // File Drag & Drop
    // =====================================

    /**
     * Setup file drag and drop
     */
    setupFileDragDrop() {
        const dropZone = document.body;
        
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
            }, false);
        });
        
        ['dragenter', 'dragover'].forEach(eventName => {
            dropZone.addEventListener(eventName, () => {
                dropZone.classList.add('drag-over');
            }, false);
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, () => {
                dropZone.classList.remove('drag-over');
            }, false);
        });
        
        dropZone.addEventListener('drop', (e) => this.handleFileDrop(e), false);
    }

    /**
     * Handle file drop
     * @param {DragEvent} e - Drag event
     */
    handleFileDrop(e) {
        const files = e.dataTransfer.files;
        if (files.length === 0) return;
        
        const file = files[0];
        const fileName = file.name.toLowerCase();
        
        let format = 'auto';
        if (fileName.endsWith('.json') || fileName.endsWith('.jsonld')) {
            format = 'json';
        } else if (fileName.endsWith('.md') || fileName.endsWith('.mmd') || fileName.endsWith('.mermaid') || fileName.endsWith('.txt')) {
            format = 'mermaid';
        }
        
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                this.importContent(e.target.result, format);
                this.showNotification(`✅ ${file.name} importiert`, 'success');
            } catch (err) {
                this.showNotification(`Import-Fehler: ${err.message}`, 'error');
            }
        };
        reader.readAsText(file);
    }

    // =====================================
    // Notifications
    // =====================================

    /**
     * Show notification
     * @param {string} message - Message
     * @param {string} type - Type (info, success, error)
     */
    showNotification(message, type = 'info') {
        if (this.dialogManager) {
            this.dialogManager.showNotification(message, type);
        } else {
            console.log(`[${type}] ${message}`);
        }
    }

    // =====================================
    // Style Management
    // =====================================

    /**
     * Apply style to item
     * @param {Object} styleData - Style data
     */
    applyStyle(styleData) {
        const item = this.hierarchyData.find(i => i.id === styleData.itemId);
        if (!item) return;
        
        item.styleClass = styleData.styleClass;
        item.customStyle = styleData.customStyle;
        
        this.saveVersion(`Style für ${styleData.itemId} geändert`);
        this.updateDisplay();
    }

    // =====================================
    // Focus Mode
    // =====================================

    /**
     * Enter focus mode
     * @param {string} itemId - Item to focus on
     */
    enterFocusMode(itemId) {
        this.focusMode = true;
        this.focusItemId = itemId;
        document.body.classList.add('focus-mode-active');
        
        const focusBar = document.getElementById('focusModeBar');
        if (focusBar) {
            focusBar.classList.add('active');
            const item = this.hierarchyData.find(i => i.id === itemId);
            const text = focusBar.querySelector('.focus-text');
            if (text) {
                text.textContent = `Fokus: ${item?.text || itemId}`;
            }
        }
        
        this.updateDisplay();
    }

    /**
     * Exit focus mode
     */
    exitFocusMode() {
        this.focusMode = false;
        this.focusItemId = null;
        document.body.classList.remove('focus-mode-active');
        
        const focusBar = document.getElementById('focusModeBar');
        if (focusBar) {
            focusBar.classList.remove('active');
        }
        
        this.updateDisplay();
    }
}

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', () => {
    window.app = new SemAViApp();
});

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { SemAViApp };
}

// Export for browser
if (typeof window !== 'undefined') {
    window.SemAViApp = SemAViApp;
}

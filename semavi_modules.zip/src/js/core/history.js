/**
 * SemAVi - History Manager
 * Undo/Redo FunktionalitÃ¤t
 */

const HistoryManager = {
    undoStack: [],
    redoStack: [],
    maxHistory: 50,
    
    /**
     * Speichert den aktuellen Zustand fÃ¼r Undo
     * @param {string} description - Beschreibung der Aktion
     */
    saveVersion(description = '') {
        // Aktuellen Zustand serialisieren
        const snapshot = {
            hierarchyData: JSON.parse(JSON.stringify(SemAViState.hierarchyData)),
            connections: JSON.parse(JSON.stringify(SemAViState.connections)),
            globalDirection: SemAViState.globalDirection,
            initBlock: SemAViState.initBlock,
            description,
            timestamp: new Date().toISOString()
        };
        
        this.undoStack.push(snapshot);
        
        // Stack begrenzen
        if (this.undoStack.length > this.maxHistory) {
            this.undoStack.shift();
        }
        
        // Redo-Stack leeren bei neuer Aktion
        this.redoStack = [];
        
        this.updateUI();
    },
    
    /**
     * Macht die letzte Aktion rÃ¼ckgÃ¤ngig
     */
    undo() {
        if (this.undoStack.length <= 1) {
            console.log('Nichts zum RÃ¼ckgÃ¤ngig machen');
            return false;
        }
        
        // Aktuellen Zustand fÃ¼r Redo speichern
        const currentState = this.undoStack.pop();
        this.redoStack.push(currentState);
        
        // Vorherigen Zustand wiederherstellen
        const previousState = this.undoStack[this.undoStack.length - 1];
        this.restoreState(previousState);
        
        if (typeof showNotification === 'function') {
            showNotification('RÃ¼ckgÃ¤ngig: ' + (currentState.description || 'Aktion'), 'info');
        }
        
        this.updateUI();
        return true;
    },
    
    /**
     * Stellt eine rÃ¼ckgÃ¤ngig gemachte Aktion wieder her
     */
    redo() {
        if (this.redoStack.length === 0) {
            console.log('Nichts zum Wiederherstellen');
            return false;
        }
        
        const nextState = this.redoStack.pop();
        this.undoStack.push(nextState);
        this.restoreState(nextState);
        
        if (typeof showNotification === 'function') {
            showNotification('Wiederherstellen: ' + (nextState.description || 'Aktion'), 'info');
        }
        
        this.updateUI();
        return true;
    },
    
    /**
     * Stellt einen gespeicherten Zustand wieder her
     * @param {Object} state - Der wiederherzustellende Zustand
     */
    restoreState(state) {
        SemAViState.hierarchyData = JSON.parse(JSON.stringify(state.hierarchyData));
        SemAViState.connections = JSON.parse(JSON.stringify(state.connections));
        SemAViState.globalDirection = state.globalDirection;
        SemAViState.initBlock = state.initBlock;
        
        // UI aktualisieren
        if (typeof updateDisplay === 'function') {
            updateDisplay();
        }
    },
    
    /**
     * Aktualisiert die UI-Buttons
     */
    updateUI() {
        const undoBtn = document.getElementById('undoBtn');
        const redoBtn = document.getElementById('redoBtn');
        
        if (undoBtn) {
            undoBtn.disabled = this.undoStack.length <= 1;
            undoBtn.title = this.undoStack.length > 1 
                ? `RÃ¼ckgÃ¤ngig: ${this.undoStack[this.undoStack.length - 1]?.description || 'Letzte Aktion'}`
                : 'Nichts zum RÃ¼ckgÃ¤ngig machen';
        }
        
        if (redoBtn) {
            redoBtn.disabled = this.redoStack.length === 0;
            redoBtn.title = this.redoStack.length > 0
                ? `Wiederherstellen: ${this.redoStack[this.redoStack.length - 1]?.description || 'NÃ¤chste Aktion'}`
                : 'Nichts zum Wiederherstellen';
        }
    },
    
    /**
     * Gibt die Anzahl der verfÃ¼gbaren Undo-Schritte zurÃ¼ck
     */
    getUndoCount() {
        return Math.max(0, this.undoStack.length - 1);
    },
    
    /**
     * Gibt die Anzahl der verfÃ¼gbaren Redo-Schritte zurÃ¼ck
     */
    getRedoCount() {
        return this.redoStack.length;
    },
    
    /**
     * LÃ¶scht die gesamte Historie
     */
    clear() {
        this.undoStack = [];
        this.redoStack = [];
        this.updateUI();
    },
    
    /**
     * Initialisiert die Historie mit dem aktuellen Zustand
     */
    init() {
        this.clear();
        this.saveVersion('Initialer Zustand');
    }
};

// Globale Funktionen fÃ¼r KompatibilitÃ¤t
function saveVersion(description) {
    HistoryManager.saveVersion(description);
}

function undo() {
    return HistoryManager.undo();
}

function redo() {
    return HistoryManager.redo();
}

// Export fÃ¼r Module
if (typeof module !== 'undefined' && module.exports) {
    module.exports = HistoryManager;
}

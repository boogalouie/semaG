/**
 * SemAVi - Unified Mermaid Parser
 * @module parser/mermaid-parser
 * @version 4.8
 * 
 * Parses Mermaid flowchart/graph syntax into a structured data model
 * and generates Mermaid code from the data model.
 */

// Arrow type definitions
const ARROW_TYPES = {
    '-->': { type: 'arrow', label: 'Pfeil' },
    '---': { type: 'line', label: 'Linie' },
    '-.->': { type: 'dotted', label: 'Gestrichelt' },
    '==>': { type: 'thick', label: 'Dick' },
    '--x': { type: 'cross', label: 'Kreuz' },
    '--o': { type: 'circle', label: 'Kreis' },
    '<-->': { type: 'bidirectional', label: 'Bidirektional' },
    '~~~': { type: 'invisible', label: 'Unsichtbar' }
};

/**
 * Unified Mermaid Parser Class
 * Handles parsing of Mermaid flowchart syntax and generation of Mermaid code
 */
class UnifiedMermaidParser {
    constructor() {
        this.reset();
        this.arrowTypes = ARROW_TYPES;
    }

    /**
     * Reset parser state
     */
    reset() {
        this.nodes = new Map();
        this.subgraphs = new Map();
        this.connections = [];
        this.classDefs = new Map();
        this.nodeStyles = new Map();
        this.linkStyles = [];
        this.globalDirection = 'TB';
        this.initBlock = '';
    }

    /**
     * Parse Mermaid code into data model
     * @param {string} code - Mermaid flowchart code
     * @returns {Object} Parsed data model
     */
    parse(code) {
        this.reset();

        // Extract init block
        const { code: cleanCode, initBlock } = this.extractInitBlock(code);
        this.initBlock = initBlock;

        // Prepare lines
        const lines = this.prepareLines(cleanCode);

        // First pass: Parse structure (subgraphs, nodes)
        this.parseStructure(lines);

        // Second pass: Parse connections and styles
        this.parseConnectionsAndStyles(lines);

        return this.toDataModel();
    }

    /**
     * Extract %%{init: ... }%% blocks from code
     * @param {string} code - Raw Mermaid code
     * @returns {Object} { code: cleanCode, initBlock: extractedInit }
     */
    extractInitBlock(code) {
        let cleanCode = code;
        let initBlock = '';

        // Match %%{init: ... }%% blocks (can span multiple lines)
        const initPattern = /%%\{init:/gi;
        const blocks = [];
        let match;

        while ((match = initPattern.exec(code)) !== null) {
            const startPos = match.index;
            let endPos = startPos;
            let braceCount = 0;
            let inInit = false;

            // Find matching closing }%%
            for (let i = startPos + match[0].length; i < code.length; i++) {
                const char = code[i];

                if (char === '{') {
                    braceCount++;
                    inInit = true;
                } else if (char === '}') {
                    if (inInit) {
                        braceCount--;
                        if (braceCount === 0) {
                            if (code.substring(i, i + 3) === '}%%') {
                                endPos = i + 3;
                                break;
                            }
                        }
                    } else if (code.substring(i, i + 3) === '}%%') {
                        endPos = i + 3;
                        break;
                    }
                }
            }

            if (endPos > startPos) {
                // Clean backticks from init block (non-standard but tolerate)
                let block = code.substring(startPos, endPos);
                block = block.replace(/`#/g, '#').replace(/`'/g, "'").replace(/`/g, '');
                blocks.push(block);
            }
        }

        if (blocks.length > 0) {
            initBlock = blocks.join('\n');
            const origRegex = /%%\{init:[\s\S]*?\}%%/gi;
            cleanCode = cleanCode.replace(origRegex, '').trim();
        }

        // Also match other directives %%{...}%% (but not init)
        const directivePattern = /%%\{(?!init)[^}]+\}%%/gi;
        const dirMatches = cleanCode.match(directivePattern);

        if (dirMatches) {
            initBlock += (initBlock ? '\n' : '') + dirMatches.join('\n');
            cleanCode = cleanCode.replace(directivePattern, '').trim();
        }

        return { code: cleanCode, initBlock };
    }

    /**
     * Prepare lines for parsing
     * @param {string} code - Clean Mermaid code
     * @returns {string[]} Array of trimmed, non-empty lines
     */
    prepareLines(code) {
        return code
            .replace(/\r\n/g, '\n')
            .split('\n')
            .map(line => line.trim())
            .filter(line => {
                if (!line) return false;
                if (line.startsWith('%%') && !line.includes('{')) return false;
                return true;
            });
    }

    /**
     * First pass: Parse structure (subgraphs and nodes)
     * @param {string[]} lines - Prepared lines
     */
    parseStructure(lines) {
        let currentSubgraph = null;
        const subgraphStack = [];
        let level = 0;

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];

            // Graph declaration with direction
            const graphMatch = line.match(/^(graph|flowchart)\s+(TD|TB|BT|RL|LR)/i);
            if (graphMatch) {
                this.globalDirection = graphMatch[2].toUpperCase();
                continue;
            }

            // Subgraph patterns
            let subgraphMatch = this.matchSubgraph(line);

            if (subgraphMatch) {
                let [, id, title] = subgraphMatch;

                if (currentSubgraph) {
                    subgraphStack.push(currentSubgraph);
                }
                level++;

                // Check for direction on next line
                let direction = null;
                if (i + 1 < lines.length) {
                    const dirMatch = lines[i + 1].match(/^\s*direction\s+(TD|TB|BT|RL|LR)/i);
                    if (dirMatch) {
                        direction = dirMatch[1].toUpperCase();
                        i++;
                    }
                }

                const subgraph = {
                    id,
                    title: title || id,
                    parent: currentSubgraph,
                    level,
                    direction,
                    nodes: [],
                    subgraphs: []
                };

                this.subgraphs.set(id, subgraph);

                if (currentSubgraph) {
                    const parent = this.subgraphs.get(currentSubgraph);
                    if (parent) {
                        parent.subgraphs.push(id);
                    }
                }

                currentSubgraph = id;
                continue;
            }

            // Subgraph end
            if (line.match(/^\s*end\s*$/i)) {
                if (subgraphStack.length > 0) {
                    currentSubgraph = subgraphStack.pop();
                    level--;
                } else {
                    currentSubgraph = null;
                    level = 0;
                }
                continue;
            }

            // Direction statement (for subgraphs)
            if (line.match(/^\s*direction\s+(TD|TB|BT|RL|LR)/i)) {
                continue; // Already handled above
            }

            // Skip style/class definitions
            if (line.match(/^\s*(classDef|style|class|linkStyle)\s+/i)) {
                continue;
            }

            // Parse node definitions
            this.parseNodeDefinitions(line, currentSubgraph, level);
        }
    }

    /**
     * Match subgraph declaration patterns
     * @param {string} line - Line to match
     * @returns {Array|null} Match result or null
     */
    matchSubgraph(line) {
        // subgraph ID["Title with spaces"]
        let match = line.match(/^\s*subgraph\s+([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*"([^"]+)"\s*\]/i);
        if (match) return match;

        // subgraph ID['Title']
        match = line.match(/^\s*subgraph\s+([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*'([^']+)'\s*\]/i);
        if (match) return match;

        // subgraph ID[Title]
        match = line.match(/^\s*subgraph\s+([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*([^\]]+)\s*\]/i);
        if (match) return match;

        // subgraph ID
        match = line.match(/^\s*subgraph\s+([A-Za-z_][A-Za-z0-9_]*)\s*$/i);
        if (match) return match;

        // subgraph "Title" (no ID - auto-generate)
        const titleOnlyDouble = line.match(/^\s*subgraph\s+"([^"]+)"\s*$/i);
        if (titleOnlyDouble) {
            const title = titleOnlyDouble[1];
            const autoId = 'SG_' + title
                .replace(/[^a-zA-Z0-9\s_-]/g, '')
                .replace(/\s+/g, '_')
                .substring(0, 30);
            return [null, autoId, title];
        }

        // subgraph 'Title' (single quotes)
        const titleOnlySingle = line.match(/^\s*subgraph\s+'([^']+)'\s*$/i);
        if (titleOnlySingle) {
            const title = titleOnlySingle[1];
            const autoId = 'SG_' + title
                .replace(/[^a-zA-Z0-9\s_-]/g, '')
                .replace(/\s+/g, '_')
                .substring(0, 30);
            return [null, autoId, title];
        }

        return null;
    }

    /**
     * Parse node definitions from a line
     * @param {string} line - Line to parse
     * @param {string|null} currentSubgraph - Current subgraph context
     * @param {number} level - Current nesting level
     */
    parseNodeDefinitions(line, currentSubgraph, level) {
        // Pattern for node definitions: ID followed by shape brackets
        const nodePattern = /([A-Za-z_][A-Za-z0-9_.-]*)\s*((?:\[\[|\[\/|\[\\|\[\(|\(\[|\(\(\(|\(\(|\{\{|\{|\[|\(|>)(?:[^\[\](){}<>]|\[(?:[^\[\]])*\]|\((?:[^\(\)])*\)|\{(?:[^\{\}])*\})*(?:\]\]|\/\]|\\]|\)\]|\]\)|}\}|\}\}|\)|\]|\}))/g;

        let match;
        while ((match = nodePattern.exec(line)) !== null) {
            const id = match[1];
            const shapeAndText = match[2];

            // Skip if this is a subgraph or arrow
            if (this.subgraphs.has(id)) continue;
            if (['-->','---','-.->','==>','--x','--o','<-->','~~~'].some(a => id.includes(a))) continue;

            const { shape, text } = this.parseShapeAndText(shapeAndText);

            // Check for inline class (:::className)
            let styleClass = null;
            const classMatch = line.substring(match.index + match[0].length).match(/^:::([\w-]+)/);
            if (classMatch) {
                styleClass = classMatch[1];
            }

            if (!this.nodes.has(id)) {
                this.nodes.set(id, {
                    id,
                    text,
                    shape,
                    subgraph: currentSubgraph,
                    level: currentSubgraph ? level : 0,
                    styleClass,
                    customStyle: null
                });

                // Add to subgraph's nodes list
                if (currentSubgraph) {
                    const sg = this.subgraphs.get(currentSubgraph);
                    if (sg && !sg.nodes.includes(id)) {
                        sg.nodes.push(id);
                    }
                }
            }
        }
    }

    /**
     * Parse shape and extract text from brackets
     * @param {string} shapeAndText - Shape with text in brackets
     * @returns {Object} { shape, text }
     */
    parseShapeAndText(shapeAndText) {
        let text = shapeAndText;
        let shape = 'rectangle';

        // Check patterns in order (longer patterns first)
        if (shapeAndText.startsWith('(((') && shapeAndText.endsWith(')))')) {
            shape = 'double-circle';
            text = shapeAndText.slice(3, -3);
        } else if (shapeAndText.startsWith('([') && shapeAndText.endsWith('])')) {
            shape = 'stadium';
            text = shapeAndText.slice(2, -2);
        } else if (shapeAndText.startsWith('((') && shapeAndText.endsWith('))')) {
            shape = 'circle';
            text = shapeAndText.slice(2, -2);
        } else if (shapeAndText.startsWith('{{') && shapeAndText.endsWith('}}')) {
            shape = 'hexagon';
            text = shapeAndText.slice(2, -2);
        } else if (shapeAndText.startsWith('[[') && shapeAndText.endsWith(']]')) {
            shape = 'subroutine';
            text = shapeAndText.slice(2, -2);
        } else if (shapeAndText.startsWith('[(') && shapeAndText.endsWith(')]')) {
            shape = 'cylindrical';
            text = shapeAndText.slice(2, -2);
        } else if (shapeAndText.startsWith('[/') && shapeAndText.endsWith('/]')) {
            shape = 'parallelogram';
            text = shapeAndText.slice(2, -2);
        } else if (shapeAndText.startsWith('[\\') && shapeAndText.endsWith('\\]')) {
            shape = 'parallelogram-alt';
            text = shapeAndText.slice(2, -2);
        } else if (shapeAndText.startsWith('[/') && shapeAndText.endsWith('\\]')) {
            shape = 'trapezoid';
            text = shapeAndText.slice(2, -2);
        } else if (shapeAndText.startsWith('[\\') && shapeAndText.endsWith('/]')) {
            shape = 'trapezoid-alt';
            text = shapeAndText.slice(2, -2);
        } else if (shapeAndText.startsWith('[') && shapeAndText.endsWith(']')) {
            shape = 'rectangle';
            text = shapeAndText.slice(1, -1);
        } else if (shapeAndText.startsWith('(') && shapeAndText.endsWith(')')) {
            shape = 'rounded';
            text = shapeAndText.slice(1, -1);
        } else if (shapeAndText.startsWith('{') && shapeAndText.endsWith('}')) {
            shape = 'rhombus';
            text = shapeAndText.slice(1, -1);
        } else if (shapeAndText.startsWith('>') && shapeAndText.endsWith(']')) {
            shape = 'asymmetric';
            text = shapeAndText.slice(1, -1);
        }

        // Remove surrounding quotes
        text = text.trim();
        if ((text.startsWith('"') && text.endsWith('"')) ||
            (text.startsWith("'") && text.endsWith("'"))) {
            text = text.slice(1, -1);
        }

        return { shape, text: text.trim() };
    }

    /**
     * Second pass: Parse connections and styles
     * @param {string[]} lines - Prepared lines
     */
    parseConnectionsAndStyles(lines) {
        let currentSubgraph = null;
        const subgraphStack = [];

        for (const line of lines) {
            // Track subgraph context
            let subgraphMatch = line.match(/^\s*subgraph\s+([A-Za-z_][A-Za-z0-9_]*)/i);

            if (!subgraphMatch) {
                const titleOnlyMatch = line.match(/^\s*subgraph\s+["']([^"']+)["']\s*$/i);
                if (titleOnlyMatch) {
                    const title = titleOnlyMatch[1];
                    const autoId = 'SG_' + title
                        .replace(/[^a-zA-Z0-9\s_-]/g, '')
                        .replace(/\s+/g, '_')
                        .substring(0, 30);
                    subgraphMatch = [null, autoId];
                }
            }

            if (subgraphMatch) {
                if (currentSubgraph) subgraphStack.push(currentSubgraph);
                currentSubgraph = subgraphMatch[1];
                continue;
            }

            if (line.match(/^\s*end\s*$/i)) {
                currentSubgraph = subgraphStack.length > 0 ? subgraphStack.pop() : null;
                continue;
            }

            // classDef
            const classDefMatch = line.match(/^\s*classDef\s+(\w+)\s+(.+)$/i);
            if (classDefMatch) {
                const [, className, styleStr] = classDefMatch;
                this.classDefs.set(className, this.parseStyleString(styleStr));
                continue;
            }

            // style (individual node style)
            const styleMatch = line.match(/^\s*style\s+([\w-]+)\s+(.+)$/i);
            if (styleMatch) {
                const [, targetId, styleStr] = styleMatch;
                const parsedStyle = this.parseStyleString(styleStr);

                if (this.nodes.has(targetId)) {
                    this.nodeStyles.set(targetId, parsedStyle);
                } else if (this.subgraphs.has(targetId)) {
                    const sg = this.subgraphs.get(targetId);
                    sg.customStyle = parsedStyle;
                } else {
                    // Search subgraph by title
                    for (const [sgId, sg] of this.subgraphs) {
                        if (sg.title && sg.title.toLowerCase() === targetId.toLowerCase()) {
                            sg.customStyle = parsedStyle;
                            break;
                        }
                        if (sgId.startsWith('SG_') && sgId.toLowerCase().includes(targetId.toLowerCase())) {
                            sg.customStyle = parsedStyle;
                            break;
                        }
                    }
                    // Store for later nodes
                    this.nodeStyles.set(targetId, parsedStyle);
                }
                continue;
            }

            // linkStyle
            const linkStyleMatch = line.match(/^\s*linkStyle\s+(\d+(?:,\d+)*)\s+(.+)$/i);
            if (linkStyleMatch) {
                const [, indices, styleStr] = linkStyleMatch;
                this.linkStyles.push({
                    indices: indices.split(',').map(i => parseInt(i)),
                    style: this.parseStyleString(styleStr)
                });
                continue;
            }

            // class assignment: class A,B,C className
            const classMatch = line.match(/^\s*class\s+([\w][\w,-]*(?:,[\w][\w,-]*)*)\s+(\w+)\s*$/i);
            if (classMatch) {
                const [, nodeIdsStr, className] = classMatch;
                const nodeIdList = nodeIdsStr.split(',').map(id => id.trim()).filter(Boolean);

                nodeIdList.forEach(id => {
                    const node = this.nodes.get(id);
                    if (node) {
                        node.styleClass = className;
                    } else {
                        const subgraph = this.subgraphs.get(id);
                        if (subgraph) {
                            subgraph.styleClass = className;
                        }
                    }
                });
                continue;
            }

            // Connections
            this.parseConnectionLine(line, currentSubgraph);
        }
    }

    /**
     * Parse style string into object
     * @param {string} styleStr - CSS-like style string
     * @returns {Object} Parsed style object
     */
    parseStyleString(styleStr) {
        const style = {};
        const parts = styleStr.split(',').map(p => p.trim());

        for (const part of parts) {
            const [key, value] = part.split(':').map(p => p.trim());
            if (key && value) {
                const cssKey = key.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
                const cleanValue = value.replace(/`/g, '');
                style[cssKey] = cleanValue;
            }
        }

        return style;
    }

    /**
     * Parse connection line
     * @param {string} line - Line containing connections
     * @param {string|null} currentSubgraph - Current subgraph context
     */
    parseConnectionLine(line, currentSubgraph) {
        // Remove inline class assignments
        let cleanLine = line.replace(/:::[A-Za-z_][A-Za-z0-9_-]*/g, '');

        // Replace node definitions with just their IDs
        const nodeDefPattern = /([A-Za-z_][A-Za-z0-9_.-]*)\s*(\[(?:[^\[\]]|\[(?:[^\[\]])*\])*\]|\((?:[^\(\)]|\((?:[^\(\)])*\))*\)|\{(?:[^\{\}]|\{(?:[^\{\}])*\})*\})/g;
        cleanLine = cleanLine.replace(nodeDefPattern, '$1');

        // Find all arrows
        const arrowRegex = /(--\s*"([^"]*)"\s*-->|--\s*'([^']*)'\s*-->|-->|<-->|--x|--o|---|-.->|==>|~~~)(\|(?:"[^"]*"|[^|]*)\|)?/g;

        const arrows = [];
        let match;
        while ((match = arrowRegex.exec(cleanLine)) !== null) {
            let label = '';
            let actualArrow = match[1];

            if (match[2]) {
                label = match[2];
                actualArrow = '-->';
            } else if (match[3]) {
                label = match[3];
                actualArrow = '-->';
            } else if (match[4]) {
                label = match[4].slice(1, -1);
                if (label.startsWith('"') && label.endsWith('"')) {
                    label = label.slice(1, -1);
                }
            }

            label = label.replace(/\\n/g, '<br/>');

            arrows.push({
                arrow: actualArrow,
                label: label,
                index: match.index,
                length: match[0].length
            });
        }

        if (arrows.length === 0) return;

        // Extract segments
        let lastEnd = 0;
        const segments = [];

        for (const arr of arrows) {
            const before = cleanLine.substring(lastEnd, arr.index).trim();
            if (before) segments.push({ type: 'node', value: before });
            segments.push({ type: 'arrow', arrow: arr.arrow, label: arr.label });
            lastEnd = arr.index + arr.length;
        }
        const lastSegment = cleanLine.substring(lastEnd).trim();
        if (lastSegment) segments.push({ type: 'node', value: lastSegment });

        // Extract node IDs
        const nodeIds = [];
        const arrowInfos = [];

        for (const seg of segments) {
            if (seg.type === 'node') {
                let nodeValue = seg.value.replace(/:::[A-Za-z_][A-Za-z0-9_-]*/g, '').trim();
                const idMatch = nodeValue.match(/([A-Za-z_][A-Za-z0-9_.-]*)\s*$/);
                if (idMatch) {
                    nodeIds.push(idMatch[1]);
                }
            } else {
                arrowInfos.push({ arrow: seg.arrow, label: seg.label });
            }
        }

        // Create connections
        for (let i = 0; i < nodeIds.length - 1; i++) {
            const fromId = nodeIds[i];
            const toId = nodeIds[i + 1];
            const arrowInfo = arrowInfos[i] || { arrow: '-->', label: '' };

            this.ensureNode(fromId, currentSubgraph);
            this.ensureNode(toId, currentSubgraph);

            const arrowType = this.arrowTypes[arrowInfo.arrow] || { type: 'arrow', label: 'Custom' };

            const exists = this.connections.some(c => c.from === fromId && c.to === toId && c.arrow === arrowInfo.arrow);
            if (!exists) {
                this.connections.push({
                    id: `conn_${this.connections.length}`,
                    from: fromId,
                    to: toId,
                    arrow: arrowInfo.arrow,
                    type: arrowType.type,
                    label: arrowInfo.label || '',
                    subgraph: currentSubgraph
                });
            }
        }
    }

    /**
     * Ensure node exists in map
     * @param {string} id - Node ID
     * @param {string|null} subgraph - Subgraph context
     */
    ensureNode(id, subgraph) {
        if (!this.nodes.has(id) && !this.subgraphs.has(id)) {
            this.nodes.set(id, {
                id,
                text: id,
                shape: 'rectangle',
                subgraph,
                level: subgraph ? this.subgraphs.get(subgraph)?.level || 0 : 0,
                styleClass: null,
                customStyle: null
            });
        }
    }

    /**
     * Convert parser state to data model
     * @returns {Object} Data model with items, connections, etc.
     */
    toDataModel() {
        const items = [];
        const connections = [];

        // Process subgraphs
        for (const [id, sg] of this.subgraphs) {
            items.push({
                id,
                text: sg.title,
                parentId: sg.parent || null,
                level: sg.level,
                isContainer: true,
                direction: sg.direction,
                styleClass: sg.styleClass || null,
                customStyle: sg.customStyle || null,
                children: [...sg.nodes, ...sg.subgraphs]
            });
        }

        // Process nodes
        for (const [id, node] of this.nodes) {
            let level = 0;
            if (node.subgraph) {
                const sg = this.subgraphs.get(node.subgraph);
                if (sg) level = sg.level + 1;
            }

            items.push({
                id,
                text: node.text,
                parentId: node.subgraph || null,
                level,
                isContainer: false,
                shape: node.shape,
                styleClass: node.styleClass || null,
                customStyle: this.nodeStyles.get(id) || null,
                children: []
            });
        }

        // Process connections
        for (const conn of this.connections) {
            connections.push({
                id: conn.id,
                from: conn.from,
                to: conn.to,
                type: conn.type,
                arrow: conn.arrow,
                label: conn.label || ''
            });
        }

        // Build classDefs object
        const classDefs = {};
        for (const [name, style] of this.classDefs) {
            classDefs[name] = style;
        }

        return {
            items,
            connections,
            globalDirection: this.globalDirection,
            initBlock: this.initBlock,
            classDefs,
            linkStyles: this.linkStyles
        };
    }

    /**
     * Generate Mermaid code from data model
     * @param {Object} data - Data model
     * @returns {string} Mermaid flowchart code
     */
    generate(data) {
        const { items, connections, globalDirection, initBlock, styleBlock, classDefs, showDetailText } = data;

        let code = '';

        // Init block
        if (initBlock && initBlock.trim()) {
            code += initBlock.trim() + '\n\n';
        }

        // Flowchart declaration
        code += `flowchart ${globalDirection || 'TB'}\n`;

        // Build hierarchy
        const rootItems = items.filter(item => !item.parentId);
        const itemMap = new Map(items.map(item => [item.id, item]));

        // Generate items
        for (const item of rootItems) {
            code += this.generateItem(item, itemMap, 1, showDetailText);
        }

        // Generate connections
        if (connections.length > 0) {
            code += '\n    %% Connections\n';
            for (const conn of connections) {
                const fromItem = itemMap.get(conn.from);
                const toItem = itemMap.get(conn.to);
                if (!fromItem || !toItem) continue;

                let arrow = conn.arrow || '-->';
                let label = conn.label ? `|"${conn.label}"|` : '';

                code += `    ${conn.from} ${arrow}${label} ${conn.to}\n`;
            }
        }

        // Class definitions
        if (classDefs && Object.keys(classDefs).length > 0) {
            code += '\n    %% Class Definitions\n';
            Object.entries(classDefs).forEach(([className, style]) => {
                const parts = [];
                if (style.fill) parts.push(`fill:${style.fill}`);
                if (style.stroke) parts.push(`stroke:${style.stroke}`);
                if (style.strokeWidth) parts.push(`stroke-width:${style.strokeWidth}`);
                if (style.color) parts.push(`color:${style.color}`);
                Object.entries(style).forEach(([key, value]) => {
                    if (!['fill', 'stroke', 'strokeWidth', 'color'].includes(key)) {
                        const cssKey = key.replace(/([A-Z])/g, '-$1').toLowerCase();
                        parts.push(`${cssKey}:${value}`);
                    }
                });
                if (parts.length > 0) {
                    code += `    classDef ${className} ${parts.join(',')}\n`;
                }
            });
        }

        // Class assignments
        const classAssignments = new Map();
        items.forEach(item => {
            if (item.styleClass) {
                if (!classAssignments.has(item.styleClass)) {
                    classAssignments.set(item.styleClass, []);
                }
                classAssignments.get(item.styleClass).push(item.id);
            }
        });

        if (classAssignments.size > 0) {
            code += '\n    %% Class Assignments\n';
            classAssignments.forEach((nodeIds, className) => {
                code += `    class ${nodeIds.join(',')} ${className}\n`;
            });
        }

        // Individual styles
        const itemsWithCustomStyle = items.filter(item => item.customStyle && Object.keys(item.customStyle).length > 0);
        if (itemsWithCustomStyle.length > 0) {
            code += '\n    %% Individual Styles\n';
            itemsWithCustomStyle.forEach(item => {
                const parts = [];
                const style = item.customStyle;
                if (style.fill) parts.push(`fill:${style.fill}`);
                if (style.stroke) parts.push(`stroke:${style.stroke}`);
                if (style.strokeWidth) parts.push(`stroke-width:${style.strokeWidth}`);
                if (style.color) parts.push(`color:${style.color}`);
                Object.entries(style).forEach(([key, value]) => {
                    if (!['fill', 'stroke', 'strokeWidth', 'color'].includes(key)) {
                        const cssKey = key.replace(/([A-Z])/g, '-$1').toLowerCase();
                        parts.push(`${cssKey}:${value}`);
                    }
                });
                if (parts.length > 0) {
                    code += `    style ${item.id} ${parts.join(',')}\n`;
                }
            });
        }

        // User-defined style block
        if (styleBlock && styleBlock.trim()) {
            code += '\n    %% Custom Styles\n';
            styleBlock.trim().split('\n').forEach(line => {
                if (line.trim()) {
                    code += `    ${line.trim()}\n`;
                }
            });
        }

        return code;
    }

    /**
     * Generate code for a single item (recursive)
     * @param {Object} item - Item to generate
     * @param {Map} itemMap - Map of all items
     * @param {number} indent - Indentation level
     * @param {boolean} showDetailText - Whether to show detail text
     * @returns {string} Generated code
     */
    generateItem(item, itemMap, indent, showDetailText = true) {
        const spaces = '    '.repeat(indent);
        let code = '';

        if (item.isContainer) {
            // Subgraph
            code += `${spaces}subgraph ${item.id}["${item.text || item.id}"]\n`;

            if (item.direction) {
                code += `${spaces}    direction ${item.direction}\n`;
            }

            // Children
            const children = (item.children || [])
                .map(childId => itemMap.get(childId))
                .filter(Boolean);

            for (const child of children) {
                code += this.generateItem(child, itemMap, indent + 1, showDetailText);
            }

            code += `${spaces}end\n`;
        } else {
            // Node
            code += `${spaces}${this.formatNode(item, showDetailText)}\n`;
        }

        return code;
    }

    /**
     * Format node with shape
     * @param {Object} item - Node item
     * @param {boolean} showDetailText - Whether to show detail text
     * @returns {string} Formatted node string
     */
    formatNode(item, showDetailText = true) {
        let displayText = item.title || item.text || '';

        if (showDetailText && item.markdownContent) {
            displayText = displayText + '<br/>' + item.markdownContent;
        }

        if (!showDetailText && displayText.includes('<br/>')) {
            displayText = displayText.split('<br/>')[0].trim();
        }

        const escapedText = displayText.replace(/"/g, '\\"');

        // Shapes requiring new @{} syntax (Mermaid 11+)
        const newSyntaxShapes = {
            'double-circle': 'dbl-circ',
            'cylindrical': 'cyl',
            'stadium': 'stadium',
            'subroutine': 'subproc',
            'hexagon': 'hex'
        };

        if (newSyntaxShapes[item.shape]) {
            return `${item.id}@{ shape: ${newSyntaxShapes[item.shape]}, label: "${escapedText}" }`;
        }

        // Classic syntax for other shapes
        const shapes = {
            'rectangle': ['[', ']'],
            'rounded': ['(', ')'],
            'stadium': ['([', '])'],
            'subroutine': ['[[', ']]'],
            'cylindrical': ['[(', ')]'],
            'circle': ['((', '))'],
            'asymmetric': ['>', ']'],
            'rhombus': ['{', '}'],
            'hexagon': ['{{', '}}'],
            'parallelogram': ['[/', '/]'],
            'parallelogram-alt': ['[\\', '\\]'],
            'trapezoid': ['[/', '\\]'],
            'trapezoid-alt': ['[\\', '/]'],
            'double-circle': ['(((', ')))']
        };

        const [open, close] = shapes[item.shape] || ['[', ']'];
        return `${item.id}${open}"${escapedText}"${close}`;
    }
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { UnifiedMermaidParser, ARROW_TYPES };
}

// Export for browser
if (typeof window !== 'undefined') {
    window.UnifiedMermaidParser = UnifiedMermaidParser;
    window.ARROW_TYPES = ARROW_TYPES;
}

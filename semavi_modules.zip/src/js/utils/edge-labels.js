/**
 * SemAVi - Edge Label Definitions
 * @module utils/edge-labels
 * @version 4.8
 * 
 * Categorized edge labels with German and schema-compatible variants
 */

/**
 * Edge label mode: 'german' for readable labels, 'schema' for camelCase without umlauts
 */
let edgeLabelMode = 'german';

/**
 * Categorized edge labels with German, schema-compatible names and predicates
 */
const EDGE_LABEL_CATEGORIES = {
    'Prozessfluss': {
        icon: '➜',
        labels: [
            { german: 'führt zu', schema: 'fuehrtZu', predicate: 'bpmn:sequenceFlow' },
            { german: 'fließt zu', schema: 'fliesstZu', predicate: 'bpmn:sequenceFlow' },
            { german: 'hat Ergebnis', schema: 'hatErgebnis', predicate: 'onto:hatErgebnis' }
        ]
    },
    'Kausalität': {
        icon: '⚡',
        labels: [
            { german: 'verursacht', schema: 'verursacht', predicate: 'onto:causes' },
            { german: 'wird verursacht von', schema: 'wirdVerursachtVon', predicate: 'onto:causedBy' },
            { german: 'löst aus', schema: 'loestAus', predicate: 'onto:löstAus' },
            { german: 'bewirkt', schema: 'bewirkt', predicate: 'onto:bewirkt' },
            { german: 'resultiert aus', schema: 'resultiertAus', predicate: 'onto:resultierenAus' },
            { german: 'erzeugt', schema: 'erzeugt', predicate: 'onto:erzeugt' }
        ]
    },
    'Logik & Abhängigkeiten': {
        icon: '🔗',
        labels: [
            { german: 'impliziert', schema: 'impliziert', predicate: 'onto:implies' },
            { german: 'bedingt', schema: 'bedingt', predicate: 'onto:bedingt' },
            { german: 'setzt voraus', schema: 'setztVoraus', predicate: 'onto:setztVoraus' },
            { german: 'erfordert', schema: 'erfordert', predicate: 'onto:erfordert' },
            { german: 'hängt ab von', schema: 'haengtAbVon', predicate: 'onto:hängtAbVon' },
            { german: 'beeinflusst', schema: 'beeinflusst', predicate: 'onto:beeinflusst' }
        ]
    },
    'Struktur & Hierarchie': {
        icon: '📁',
        labels: [
            { german: 'ist Teil von', schema: 'istTeilVon', predicate: 'dcterms:isPartOf' },
            { german: 'hat Teil', schema: 'hatTeil', predicate: 'dcterms:hasPart' },
            { german: 'enthält', schema: 'enthaelt', predicate: 'onto:enthält' },
            { german: 'ist enthalten in', schema: 'istEnthaltenIn', predicate: 'onto:istEnthaltenIn' },
            { german: 'umfasst', schema: 'umfasst', predicate: 'onto:umfasst' },
            { german: 'besteht aus', schema: 'bestehtAus', predicate: 'onto:bestehtAus' },
            { german: 'gliedert sich in', schema: 'gliedertSichIn', predicate: 'onto:gliedertSichIn' }
        ]
    },
    'Referenzen & Bezüge': {
        icon: '🔍',
        labels: [
            { german: 'referenziert', schema: 'referenziert', predicate: 'schema:references' },
            { german: 'verweist auf', schema: 'verweistAuf', predicate: 'onto:verweistAuf' },
            { german: 'bezieht sich auf', schema: 'beziehtSichAuf', predicate: 'onto:beziehtSichAuf' },
            { german: 'basiert auf', schema: 'basiertAuf', predicate: 'onto:basiertAuf' },
            { german: 'ist Basis für', schema: 'istBasisFuer', predicate: 'onto:istBasisFür' },
            { german: 'entspricht', schema: 'entspricht', predicate: 'skos:closeMatch' }
        ]
    },
    'Prozesse & Funktionen': {
        icon: '⚙️',
        labels: [
            { german: 'regelt', schema: 'regelt', predicate: 'onto:regelt' },
            { german: 'bestimmt', schema: 'bestimmt', predicate: 'onto:bestimmt' },
            { german: 'definiert', schema: 'definiert', predicate: 'onto:definiert' },
            { german: 'beschreibt', schema: 'beschreibt', predicate: 'onto:beschreibt' },
            { german: 'konkretisiert', schema: 'konkretisiert', predicate: 'onto:konkretisiert' },
            { german: 'spezifiziert', schema: 'spezifiziert', predicate: 'onto:spezifiziert' }
        ]
    },
    'Zeitliche Relationen': {
        icon: '⏱️',
        labels: [
            { german: 'folgt auf', schema: 'folgtAuf', predicate: 'onto:folgtAuf' },
            { german: 'geht voraus', schema: 'gehtVoraus', predicate: 'onto:gehtVoraus' },
            { german: 'löst ab', schema: 'loestAb', predicate: 'onto:löstAb' }
        ]
    },
    'BPMN Relationen': {
        icon: '🔄',
        labels: [
            { german: 'benötigt', schema: 'benoetigt', predicate: 'bpmn:requires' },
            { german: 'produziert', schema: 'produziert', predicate: 'bpmn:produces' },
            { german: 'verzweigt zu', schema: 'verzweigtZu', predicate: 'bpmn:branchesTo' },
            { german: 'synchronisiert mit', schema: 'synchronisiertMit', predicate: 'bpmn:synchronizesWith' }
        ]
    },
    'Verwandtschaft': {
        icon: '🤝',
        labels: [
            { german: 'verwandt mit', schema: 'verwandtMit', predicate: 'skos:related' },
            { german: 'siehe auch', schema: 'sieheAuch', predicate: 'schema:seeAlso' },
            { german: 'schließt aus', schema: 'schliesstAus', predicate: 'onto:schliesstAus' },
            { german: 'erfordert Prüfung', schema: 'erfordertPruefung', predicate: 'onto:erfordertPruefung' },
            { german: 'prüft gegen', schema: 'prueftGegen', predicate: 'onto:prueftGegen' }
        ]
    }
};

/**
 * Inverse label mappings for German labels
 */
const INVERSE_LABELS_GERMAN = {
    'führt zu': 'wird erreicht von',
    'ist Teil von': 'enthält',
    'enthält': 'ist Teil von',
    'erfordert': 'wird erfordert von',
    'basiert auf': 'ist Basis für',
    'ist Basis für': 'basiert auf',
    'folgt auf': 'wird gefolgt von',
    'wird gefolgt von': 'folgt auf',
    'referenziert': 'wird referenziert von',
    'wird referenziert von': 'referenziert',
    'benötigt': 'wird benötigt von',
    'wird benötigt von': 'benötigt',
    'erzeugt': 'wird erzeugt von',
    'wird erzeugt von': 'erzeugt',
    'verweist auf': 'wird verwiesen von',
    'synchronisiert mit': 'synchronisiert mit',
    'entspricht': 'entspricht',
    'verwandt mit': 'verwandt mit',
    'bedingt': 'wird bedingt von',
    'regelt': 'wird geregelt von',
    'beschreibt': 'wird beschrieben von',
    'definiert': 'wird definiert von',
    'beeinflusst': 'wird beeinflusst von',
    'verursacht': 'wird verursacht von',
    'wird verursacht von': 'verursacht',
    'löst aus': 'wird ausgelöst von',
    'wird ausgelöst von': 'löst aus'
};

/**
 * Inverse label mappings for schema labels
 */
const INVERSE_LABELS_SCHEMA = {
    'fuehrtZu': 'wirdErreichtVon',
    'istTeilVon': 'enthaelt',
    'enthaelt': 'istTeilVon',
    'erfordert': 'wirdErfordertVon',
    'basiertAuf': 'istBasisFuer',
    'istBasisFuer': 'basiertAuf',
    'folgtAuf': 'wirdGefolgtVon',
    'wirdGefolgtVon': 'folgtAuf',
    'referenziert': 'wirdReferenziertVon',
    'benoetigt': 'wirdBenoetigtVon',
    'erzeugt': 'wirdErzeugtVon',
    'synchronisiertMit': 'synchronisiertMit',
    'entspricht': 'entspricht',
    'verwandtMit': 'verwandtMit',
    'verursacht': 'wirdVerursachtVon',
    'wirdVerursachtVon': 'verursacht'
};

// Imported ontology labels (populated on import)
let importedOntologyLabels = [];

// Flat label map for quick access (generated)
let EDGE_LABEL_TYPES = {};

/**
 * Rebuild the flat label types map
 */
function rebuildEdgeLabelTypes() {
    EDGE_LABEL_TYPES = {};
    Object.values(EDGE_LABEL_CATEGORIES).forEach(cat => {
        cat.labels.forEach(l => {
            const key = edgeLabelMode === 'german' ? l.german : l.schema;
            EDGE_LABEL_TYPES[key] = l.predicate;
        });
    });
    // Add imported ontology labels
    importedOntologyLabels.forEach(l => {
        if (!EDGE_LABEL_TYPES[l.label]) {
            EDGE_LABEL_TYPES[l.label] = l.predicate || 'onto:' + l.label.replace(/\s+/g, '');
        }
    });
}

/**
 * Get label in current mode
 * @param {Object} labelObj - Label object with german and schema properties
 * @returns {string} Label in current mode
 */
function getLabelInCurrentMode(labelObj) {
    return edgeLabelMode === 'german' ? labelObj.german : labelObj.schema;
}

/**
 * Get all labels as flat list with metadata
 * @returns {Array} Array of label objects
 */
function getAllLabelsFlat() {
    const labels = [];
    Object.entries(EDGE_LABEL_CATEGORIES).forEach(([catName, cat]) => {
        cat.labels.forEach(l => {
            labels.push({
                label: getLabelInCurrentMode(l),
                german: l.german,
                schema: l.schema,
                predicate: l.predicate,
                category: catName,
                icon: cat.icon
            });
        });
    });
    // Add imported ontology labels
    importedOntologyLabels.forEach(l => {
        labels.push({
            label: l.label,
            german: l.label,
            schema: l.label,
            predicate: l.predicate || 'onto:' + l.label.replace(/\s+/g, ''),
            category: 'Aus Ontologie',
            icon: '📄'
        });
    });
    return labels;
}

/**
 * Get inverse label for a given label
 * @param {string} label - Original label
 * @returns {string} Inverse label or prefixed original
 */
function getInverseLabel(label) {
    if (edgeLabelMode === 'german') {
        return INVERSE_LABELS_GERMAN[label] || 'inv:' + label;
    } else {
        return INVERSE_LABELS_SCHEMA[label] || 'inv' + label.charAt(0).toUpperCase() + label.slice(1);
    }
}

/**
 * Get inverse arrow type
 * @param {string} arrow - Original arrow
 * @returns {string} Inverse arrow
 */
function getInverseArrow(arrow) {
    const inverseMap = {
        '-->': '-->',
        '---': '---',
        '-.->': '-.->',
        '==>': '==>',
        '--x': '--x',
        '--o': '--o',
        '<-->': '<-->'
    };
    return inverseMap[arrow] || '-->';
}

/**
 * Set edge label mode
 * @param {string} mode - 'german' or 'schema'
 */
function setEdgeLabelMode(mode) {
    if (mode === 'german' || mode === 'schema') {
        edgeLabelMode = mode;
        rebuildEdgeLabelTypes();
    }
}

/**
 * Get current edge label mode
 * @returns {string} Current mode
 */
function getEdgeLabelMode() {
    return edgeLabelMode;
}

/**
 * Add imported ontology labels
 * @param {Array} labels - Array of label objects
 */
function addImportedOntologyLabels(labels) {
    importedOntologyLabels = labels;
    rebuildEdgeLabelTypes();
}

/**
 * Get used labels with count from connections
 * @param {Array} connections - Array of connections
 * @returns {Map} Map of label to count
 */
function getUsedLabelsWithCount(connections) {
    const labelCounts = new Map();
    connections.forEach(conn => {
        if (conn.label) {
            labelCounts.set(conn.label, (labelCounts.get(conn.label) || 0) + 1);
        }
    });
    return labelCounts;
}

/**
 * Search labels by query
 * @param {string} query - Search query
 * @param {Array} connections - Current connections for usage info
 * @returns {Array} Filtered labels with usage info
 */
function searchLabels(query, connections = []) {
    const allLabels = getAllLabelsFlat();
    const usedLabels = getUsedLabelsWithCount(connections);
    const queryLower = query.toLowerCase().trim();

    if (!queryLower) {
        return allLabels.map(l => ({
            ...l,
            count: usedLabels.get(l.label) || 0,
            isUsed: usedLabels.has(l.label)
        }));
    }

    return allLabels
        .filter(l => 
            l.label.toLowerCase().includes(queryLower) ||
            l.german.toLowerCase().includes(queryLower) ||
            l.schema.toLowerCase().includes(queryLower) ||
            l.category.toLowerCase().includes(queryLower)
        )
        .map(l => ({
            ...l,
            count: usedLabels.get(l.label) || 0,
            isUsed: usedLabels.has(l.label)
        }));
}

/**
 * Get quick labels (frequently used + defaults)
 * @param {Array} connections - Current connections
 * @param {number} maxCount - Maximum number of labels
 * @returns {Array} Quick labels
 */
function getQuickLabels(connections = [], maxCount = 6) {
    const usedLabels = getUsedLabelsWithCount(connections);
    const allLabels = getAllLabelsFlat();
    const quickLabels = [];

    // First: used labels sorted by frequency
    const usedEntries = Array.from(usedLabels.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 4);

    usedEntries.forEach(([label, count]) => {
        const labelObj = allLabels.find(l => l.label === label || l.german === label || l.schema === label);
        quickLabels.push({
            label: label,
            count: count,
            isUsed: true,
            icon: labelObj?.icon || '📊'
        });
    });

    // Fill with defaults
    const defaultLabels = edgeLabelMode === 'german'
        ? ['führt zu', 'ist Teil von', 'erfordert', 'basiert auf', 'folgt auf', 'entspricht']
        : ['fuehrtZu', 'istTeilVon', 'erfordert', 'basiertAuf', 'folgtAuf', 'entspricht'];

    defaultLabels.forEach(label => {
        if (quickLabels.length < maxCount && !quickLabels.find(q => q.label === label)) {
            const labelObj = allLabels.find(l => l.label === label || l.german === label || l.schema === label);
            if (labelObj) {
                quickLabels.push({
                    label: labelObj.label,
                    count: 0,
                    isUsed: false,
                    icon: labelObj.icon
                });
            }
        }
    });

    return quickLabels;
}

// Initialize
rebuildEdgeLabelTypes();

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        EDGE_LABEL_CATEGORIES,
        EDGE_LABEL_TYPES,
        INVERSE_LABELS_GERMAN,
        INVERSE_LABELS_SCHEMA,
        rebuildEdgeLabelTypes,
        getLabelInCurrentMode,
        getAllLabelsFlat,
        getInverseLabel,
        getInverseArrow,
        setEdgeLabelMode,
        getEdgeLabelMode,
        addImportedOntologyLabels,
        getUsedLabelsWithCount,
        searchLabels,
        getQuickLabels
    };
}

// Export for browser
if (typeof window !== 'undefined') {
    window.EdgeLabels = {
        EDGE_LABEL_CATEGORIES,
        EDGE_LABEL_TYPES,
        INVERSE_LABELS_GERMAN,
        INVERSE_LABELS_SCHEMA,
        rebuildEdgeLabelTypes,
        getLabelInCurrentMode,
        getAllLabelsFlat,
        getInverseLabel,
        getInverseArrow,
        setEdgeLabelMode,
        getEdgeLabelMode,
        addImportedOntologyLabels,
        getUsedLabelsWithCount,
        searchLabels,
        getQuickLabels
    };
}

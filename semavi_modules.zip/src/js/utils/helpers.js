/**
 * SemAVi - Helper Functions
 * @module utils/helpers
 * @version 4.8
 * 
 * General utility functions used throughout the application
 */

/**
 * Generate a unique ID
 * @param {string} prefix - Optional prefix
 * @returns {string} Unique ID
 */
function generateUniqueId(prefix = '') {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substr(2, 9);
    return prefix ? `${prefix}_${timestamp}_${random}` : `${timestamp}_${random}`;
}

/**
 * Deep clone an object
 * @param {Object} obj - Object to clone
 * @returns {Object} Cloned object
 */
function deepClone(obj) {
    if (obj === null || typeof obj !== 'object') {
        return obj;
    }
    
    if (obj instanceof Date) {
        return new Date(obj.getTime());
    }
    
    if (obj instanceof Array) {
        return obj.map(item => deepClone(item));
    }
    
    if (obj instanceof Set) {
        return new Set([...obj].map(item => deepClone(item)));
    }
    
    if (obj instanceof Map) {
        const clonedMap = new Map();
        obj.forEach((value, key) => {
            clonedMap.set(deepClone(key), deepClone(value));
        });
        return clonedMap;
    }
    
    const cloned = {};
    for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
            cloned[key] = deepClone(obj[key]);
        }
    }
    return cloned;
}

/**
 * Debounce a function
 * @param {Function} func - Function to debounce
 * @param {number} wait - Wait time in milliseconds
 * @returns {Function} Debounced function
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Throttle a function
 * @param {Function} func - Function to throttle
 * @param {number} limit - Time limit in milliseconds
 * @returns {Function} Throttled function
 */
function throttle(func, limit) {
    let inThrottle;
    return function executedFunction(...args) {
        if (!inThrottle) {
            func(...args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

/**
 * Escape HTML entities
 * @param {string} str - String to escape
 * @returns {string} Escaped string
 */
function escapeHtml(str) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return String(str).replace(/[&<>"']/g, m => map[m]);
}

/**
 * Unescape HTML entities
 * @param {string} str - String to unescape
 * @returns {string} Unescaped string
 */
function unescapeHtml(str) {
    const map = {
        '&amp;': '&',
        '&lt;': '<',
        '&gt;': '>',
        '&quot;': '"',
        '&#039;': "'"
    };
    return String(str).replace(/&amp;|&lt;|&gt;|&quot;|&#039;/g, m => map[m]);
}

/**
 * Sanitize ID string (remove special characters)
 * @param {string} str - String to sanitize
 * @returns {string} Sanitized ID
 */
function sanitizeId(str) {
    return String(str)
        .replace(/[^a-zA-Z0-9_-]/g, '_')
        .replace(/^[^a-zA-Z_]/, '_')
        .replace(/__+/g, '_')
        .substring(0, 50);
}

/**
 * Truncate string with ellipsis
 * @param {string} str - String to truncate
 * @param {number} maxLength - Maximum length
 * @returns {string} Truncated string
 */
function truncate(str, maxLength = 50) {
    if (!str || str.length <= maxLength) {
        return str;
    }
    return str.substring(0, maxLength - 3) + '...';
}

/**
 * Format date for display
 * @param {Date|string} date - Date to format
 * @param {string} locale - Locale for formatting
 * @returns {string} Formatted date string
 */
function formatDate(date, locale = 'de-DE') {
    const d = date instanceof Date ? date : new Date(date);
    return d.toLocaleDateString(locale, {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    });
}

/**
 * Format file size
 * @param {number} bytes - Size in bytes
 * @returns {string} Formatted size string
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Download content as file
 * @param {string} content - File content
 * @param {string} filename - File name
 * @param {string} mimeType - MIME type
 */
function downloadFile(content, filename, mimeType = 'text/plain') {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

/**
 * Copy text to clipboard
 * @param {string} text - Text to copy
 * @returns {Promise<boolean>} Success status
 */
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        return true;
    } catch (err) {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-9999px';
        document.body.appendChild(textArea);
        textArea.select();
        
        try {
            document.execCommand('copy');
            return true;
        } catch (e) {
            console.error('Copy to clipboard failed:', e);
            return false;
        } finally {
            document.body.removeChild(textArea);
        }
    }
}

/**
 * Read file as text
 * @param {File} file - File to read
 * @returns {Promise<string>} File content
 */
function readFileAsText(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = e => resolve(e.target.result);
        reader.onerror = () => reject(new Error('Failed to read file'));
        reader.readAsText(file);
    });
}

/**
 * Get color for level
 * @param {number} level - Hierarchy level
 * @returns {string} CSS color variable
 */
function getLevelColor(level) {
    const colors = [
        'var(--level-0)',
        'var(--level-1)',
        'var(--level-2)',
        'var(--level-3)',
        'var(--level-4)',
        'var(--level-5)',
        'var(--level-6)',
        'var(--level-7)',
        'var(--level-8)',
        'var(--level-9)'
    ];
    return colors[level % colors.length];
}

/**
 * Check if color is dark
 * @param {string} color - Hex color string
 * @returns {boolean} True if dark
 */
function isColorDark(color) {
    const hex = color.replace('#', '');
    const r = parseInt(hex.substr(0, 2), 16);
    const g = parseInt(hex.substr(2, 2), 16);
    const b = parseInt(hex.substr(4, 2), 16);
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance < 0.5;
}

/**
 * Convert hex color to RGB
 * @param {string} hex - Hex color string
 * @returns {Object} RGB object {r, g, b}
 */
function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

/**
 * Convert RGB to hex color
 * @param {number} r - Red value
 * @param {number} g - Green value
 * @param {number} b - Blue value
 * @returns {string} Hex color string
 */
function rgbToHex(r, g, b) {
    return '#' + [r, g, b].map(x => {
        const hex = x.toString(16);
        return hex.length === 1 ? '0' + hex : hex;
    }).join('');
}

/**
 * Parse CSS style string to object
 * @param {string} styleStr - CSS style string
 * @returns {Object} Style object
 */
function parseStyleString(styleStr) {
    const style = {};
    if (!styleStr) return style;
    
    styleStr.split(';').forEach(part => {
        const [key, value] = part.split(':').map(s => s.trim());
        if (key && value) {
            const camelKey = key.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
            style[camelKey] = value;
        }
    });
    
    return style;
}

/**
 * Convert style object to CSS string
 * @param {Object} styleObj - Style object
 * @returns {string} CSS style string
 */
function styleObjectToString(styleObj) {
    return Object.entries(styleObj)
        .map(([key, value]) => {
            const kebabKey = key.replace(/([A-Z])/g, '-$1').toLowerCase();
            return `${kebabKey}: ${value}`;
        })
        .join('; ');
}

/**
 * Get element's absolute position
 * @param {HTMLElement} element - DOM element
 * @returns {Object} Position {x, y, width, height}
 */
function getElementPosition(element) {
    const rect = element.getBoundingClientRect();
    return {
        x: rect.left + window.scrollX,
        y: rect.top + window.scrollY,
        width: rect.width,
        height: rect.height
    };
}

/**
 * Check if element is visible in viewport
 * @param {HTMLElement} element - DOM element
 * @returns {boolean} True if visible
 */
function isElementInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

/**
 * Scroll element into view with offset
 * @param {HTMLElement} element - DOM element
 * @param {Object} options - Options {behavior, block, offset}
 */
function scrollIntoViewWithOffset(element, options = {}) {
    const { behavior = 'smooth', block = 'center', offset = 0 } = options;
    
    const rect = element.getBoundingClientRect();
    const absoluteTop = rect.top + window.scrollY - offset;
    
    window.scrollTo({
        top: absoluteTop,
        behavior
    });
}

/**
 * Wait for element to exist in DOM
 * @param {string} selector - CSS selector
 * @param {number} timeout - Timeout in milliseconds
 * @returns {Promise<HTMLElement>} Element when found
 */
function waitForElement(selector, timeout = 5000) {
    return new Promise((resolve, reject) => {
        const element = document.querySelector(selector);
        if (element) {
            return resolve(element);
        }
        
        const observer = new MutationObserver((mutations, obs) => {
            const el = document.querySelector(selector);
            if (el) {
                obs.disconnect();
                resolve(el);
            }
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
        
        setTimeout(() => {
            observer.disconnect();
            reject(new Error(`Element ${selector} not found within ${timeout}ms`));
        }, timeout);
    });
}

/**
 * Create element with attributes
 * @param {string} tag - Tag name
 * @param {Object} attrs - Attributes
 * @param {string|HTMLElement[]} children - Children
 * @returns {HTMLElement} Created element
 */
function createElement(tag, attrs = {}, children = []) {
    const element = document.createElement(tag);
    
    Object.entries(attrs).forEach(([key, value]) => {
        if (key === 'className') {
            element.className = value;
        } else if (key === 'style' && typeof value === 'object') {
            Object.assign(element.style, value);
        } else if (key.startsWith('on')) {
            element.addEventListener(key.substring(2).toLowerCase(), value);
        } else if (key === 'dataset') {
            Object.entries(value).forEach(([dataKey, dataValue]) => {
                element.dataset[dataKey] = dataValue;
            });
        } else {
            element.setAttribute(key, value);
        }
    });
    
    if (typeof children === 'string') {
        element.textContent = children;
    } else if (Array.isArray(children)) {
        children.forEach(child => {
            if (typeof child === 'string') {
                element.appendChild(document.createTextNode(child));
            } else if (child instanceof HTMLElement) {
                element.appendChild(child);
            }
        });
    }
    
    return element;
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        generateUniqueId,
        deepClone,
        debounce,
        throttle,
        escapeHtml,
        unescapeHtml,
        sanitizeId,
        truncate,
        formatDate,
        formatFileSize,
        downloadFile,
        copyToClipboard,
        readFileAsText,
        getLevelColor,
        isColorDark,
        hexToRgb,
        rgbToHex,
        parseStyleString,
        styleObjectToString,
        getElementPosition,
        isElementInViewport,
        scrollIntoViewWithOffset,
        waitForElement,
        createElement
    };
}

// Export for browser
if (typeof window !== 'undefined') {
    window.SemAViHelpers = {
        generateUniqueId,
        deepClone,
        debounce,
        throttle,
        escapeHtml,
        unescapeHtml,
        sanitizeId,
        truncate,
        formatDate,
        formatFileSize,
        downloadFile,
        copyToClipboard,
        readFileAsText,
        getLevelColor,
        isColorDark,
        hexToRgb,
        rgbToHex,
        parseStyleString,
        styleObjectToString,
        getElementPosition,
        isElementInViewport,
        scrollIntoViewWithOffset,
        waitForElement,
        createElement
    };
}
